package com.example.ui.admin

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.AdminSection
import com.example.viewmodel.AppScreen
import com.example.viewmodel.SevenProViewModel
import java.util.UUID

@Composable
fun AdminDashboardScreen(viewModel: SevenProViewModel) {
    val currentSection by viewModel.adminSection.collectAsState()

    Scaffold(
        containerColor = Navy800,
        topBar = {
            AdminTopBar(viewModel = viewModel)
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Horizontal Admin Navigation Tabs for the 8 sections
            AdminSectionTabs(
                selectedSection = currentSection,
                onSelect = { viewModel.setAdminSection(it) }
            )

            HorizontalDivider(color = Navy500, thickness = 1.dp)

            // Section Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (currentSection) {
                    AdminSection.DASHBOARD -> AdminHomeSection(viewModel)
                    AdminSection.STUDENTS -> AdminStudentsSection(viewModel)
                    AdminSection.COURSES -> AdminCoursesSection(viewModel)
                    AdminSection.LESSONS -> AdminLessonsSection(viewModel)
                    AdminSection.PERMISSIONS -> AdminPermissionsSection(viewModel)
                    AdminSection.APPEARANCE -> AdminAppearanceSection(viewModel)
                    AdminSection.SETTINGS -> AdminSettingsSection(viewModel)
                    AdminSection.SECURITY -> AdminSecuritySection(viewModel)
                }
            }
        }
    }
}

@Composable
fun AdminTopBar(viewModel: SevenProViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Navy900)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: 7PRO Logo and Student switch
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "7PRO",
                color = Gold500,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            OutlinedButton(
                onClick = { viewModel.switchRoleToStudent() },
                modifier = Modifier.height(32.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold500.copy(alpha = 0.6f))
            ) {
                Text("عرض كطالب", color = Gold400, fontSize = 11.sp)
            }
        }

        // Right: Admin Title & Logout
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "الرئيسية",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "مدير 7PRO",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = { viewModel.logout() },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    Icons.Default.ExitToApp,
                    contentDescription = "تسجيل الخروج",
                    tint = RoseRed
                )
            }
        }
    }
}

@Composable
fun AdminSectionTabs(
    selectedSection: AdminSection,
    onSelect: (AdminSection) -> Unit
) {
    ScrollableTabRow(
        selectedTabIndex = selectedSection.ordinal,
        containerColor = Navy900,
        contentColor = Gold500,
        edgePadding = 12.dp,
        divider = {}
    ) {
        val sections = listOf(
            AdminSection.DASHBOARD to "الرئيسية",
            AdminSection.STUDENTS to "الطلاب",
            AdminSection.COURSES to "الكورسات",
            AdminSection.LESSONS to "الدروس والفيديوهات",
            AdminSection.PERMISSIONS to "الصلاحيات",
            AdminSection.APPEARANCE to "المظهر",
            AdminSection.SETTINGS to "الإعدادات",
            AdminSection.SECURITY to "الأمان والنسخ الاحتياطي"
        )

        sections.forEach { (section, title) ->
            Tab(
                selected = selectedSection == section,
                onClick = { onSelect(section) },
                text = {
                    Text(
                        text = title,
                        fontWeight = if (selectedSection == section) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 13.sp,
                        color = if (selectedSection == section) Gold500 else TextSecondary
                    )
                }
            )
        }
    }
}

// 1. Dashboard Section (Matches Screenshot 5)
@Composable
fun AdminHomeSection(viewModel: SevenProViewModel) {
    val students by viewModel.students.collectAsState()
    val courses by viewModel.courses.collectAsState()
    val lessons by viewModel.lessons.collectAsState()

    val totalStudents = students.count { it.role == UserRole.STUDENT }
    val activeStudents = students.count { it.role == UserRole.STUDENT && it.status == UserStatus.ACTIVE }
    val pendingStudents = students.count { it.role == UserRole.STUDENT && it.status == UserStatus.PENDING }
    val totalCourses = courses.size
    val totalLessons = lessons.size
    val totalVideos = lessons.count { it.videoUrl.isNotBlank() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Stats Grid (6 cards)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard("إجمالي الطلاب", "$totalStudents", Modifier.weight(1f))
                    StatCard("الطلاب النشطون", "$activeStudents", Modifier.weight(1f))
                    StatCard("قيد المراجعة", "$pendingStudents", Modifier.weight(1f))
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard("الكورسات", "$totalCourses", Modifier.weight(1f))
                    StatCard("الدروس", "$totalLessons", Modifier.weight(1f))
                    StatCard("الفيديوهات", "$totalVideos", Modifier.weight(1f))
                }
            }
        }

        item {
            // Quick Actions (إجراءات سريعة)
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "إجراءات سريعة",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setAdminSection(AdminSection.STUDENTS) },
                            colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text("+ إضافة طالب", color = Navy900, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { viewModel.setAdminSection(AdminSection.COURSES) },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text("+ إضافة كورس", color = TextPrimary, fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setAdminSection(AdminSection.LESSONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text("+ إضافة درس", color = TextPrimary, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { viewModel.setAdminSection(AdminSection.LESSONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text("+ إضافة فيديو", color = TextPrimary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            // Recent Students & Recent Courses Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Recent Students
                Surface(
                    color = Navy700,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "أحدث الطلاب",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        students.filter { it.role == UserRole.STUDENT }.take(3).forEach { st ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = if (st.status == UserStatus.ACTIVE) EmeraldDark else RoseBg,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (st.status == UserStatus.ACTIVE) "نشط" else "معلق",
                                        color = if (st.status == UserStatus.ACTIVE) EmeraldGreen else RoseRed,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(st.name, color = TextPrimary, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Recent Courses
                Surface(
                    color = Navy700,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "آخر الكورسات المعدّلة",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        courses.take(3).forEach { cr ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = EmeraldDark,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "منشور",
                                        color = EmeraldGreen,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    cr.title,
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = Navy700,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = TextSecondary,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// 2. Students Section (الطلاب)
@Composable
fun AdminStudentsSection(viewModel: SevenProViewModel) {
    val students by viewModel.students.collectAsState()
    val courses by viewModel.courses.collectAsState()
    val assignments by viewModel.assignments.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedStudentForCourses by remember { mutableStateOf<Student?>(null) }
    var studentToEditPassword by remember { mutableStateOf<Student?>(null) }
    var newPasswordInput by remember { mutableStateOf("") }

    val filteredStudents = students.filter {
        it.role == UserRole.STUDENT && (it.name.contains(searchQuery, true) || it.email.contains(searchQuery, true))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ إضافة طالب", color = Navy900, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "إدارة الطلاب (${filteredStudents.size})",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("بحث عن طالب بالاسم أو البريد...", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold500,
                    unfocusedBorderColor = Navy500,
                    focusedContainerColor = Navy700,
                    unfocusedContainerColor = Navy700,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(8.dp),
                singleLine = true
            )
        }

        items(filteredStudents) { student ->
            val studentCoursesCount = assignments.count { it.studentId == student.id }

            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Status Badge
                        Surface(
                            color = when (student.status) {
                                UserStatus.ACTIVE -> EmeraldDark
                                UserStatus.PENDING -> AmberPending.copy(alpha = 0.25f)
                                UserStatus.DISABLED -> RoseBg
                            },
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = when (student.status) {
                                    UserStatus.ACTIVE -> "نشط"
                                    UserStatus.PENDING -> "قيد المراجعة"
                                    UserStatus.DISABLED -> "معطل"
                                },
                                color = when (student.status) {
                                    UserStatus.ACTIVE -> EmeraldGreen
                                    UserStatus.PENDING -> Gold400
                                    UserStatus.DISABLED -> RoseRed
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(student.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(student.email, color = TextSecondary, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Navy600)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Status Actions
                            if (student.status == UserStatus.PENDING) {
                                TextButton(
                                    onClick = { viewModel.repository.updateStudentStatus(student.id, UserStatus.ACTIVE) }
                                ) {
                                    Text("قبول ✓", color = EmeraldGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                TextButton(
                                    onClick = { viewModel.repository.updateStudentStatus(student.id, UserStatus.DISABLED) }
                                ) {
                                    Text("رفض ✕", color = RoseRed, fontSize = 12.sp)
                                }
                            } else if (student.status == UserStatus.ACTIVE) {
                                TextButton(
                                    onClick = { viewModel.repository.updateStudentStatus(student.id, UserStatus.DISABLED) }
                                ) {
                                    Text("تعطيل", color = RoseRed, fontSize = 12.sp)
                                }
                            } else {
                                TextButton(
                                    onClick = { viewModel.repository.updateStudentStatus(student.id, UserStatus.ACTIVE) }
                                ) {
                                    Text("تفعيل", color = EmeraldGreen, fontSize = 12.sp)
                                }
                            }

                            // Change Password
                            TextButton(onClick = {
                                studentToEditPassword = student
                                newPasswordInput = ""
                            }) {
                                Text("كلمة المرور", color = Gold400, fontSize = 12.sp)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { selectedStudentForCourses = student },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("الكورسات ($studentCoursesCount)", color = TextPrimary, fontSize = 11.sp)
                            }

                            IconButton(
                                onClick = { viewModel.repository.deleteStudent(student.id) },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RoseRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Student Dialog
    if (showAddDialog) {
        var addName by remember { mutableStateOf("") }
        var addEmail by remember { mutableStateOf("") }
        var addPass by remember { mutableStateOf("123456") }
        var addStatus by remember { mutableStateOf(UserStatus.ACTIVE) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = Navy700,
            title = { Text("إضافة طالب جديد", color = TextPrimary, textAlign = TextAlign.Right) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = addName,
                        onValueChange = { addName = it },
                        label = { Text("اسم الطالب", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addEmail,
                        onValueChange = { addEmail = it },
                        label = { Text("البريد الإلكتروني", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addPass,
                        onValueChange = { addPass = it },
                        label = { Text("كلمة المرور المؤقتة", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (addName.isNotBlank() && addEmail.isNotBlank()) {
                            viewModel.repository.addStudentByAdmin(addName, addEmail, addPass, addStatus)
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("إضافة", color = Navy900, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }

    // Change Password Dialog
    if (studentToEditPassword != null) {
        AlertDialog(
            onDismissRequest = { studentToEditPassword = null },
            containerColor = Navy700,
            title = { Text("تغيير كلمة المرور لـ ${studentToEditPassword?.name}", color = TextPrimary, textAlign = TextAlign.Right) },
            text = {
                OutlinedTextField(
                    value = newPasswordInput,
                    onValueChange = { newPasswordInput = it },
                    label = { Text("كلمة المرور الجديدة", color = TextSecondary) },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPasswordInput.isNotBlank()) {
                            viewModel.repository.updateStudentPassword(studentToEditPassword!!.id, newPasswordInput)
                            studentToEditPassword = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("حفظ", color = Navy900, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToEditPassword = null }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }

    // Student Courses Dialog (الطلاب -> الطالب -> الكورسات)
    if (selectedStudentForCourses != null) {
        val student = selectedStudentForCourses!!
        val studentAssignedIds = assignments.filter { it.studentId == student.id }.map { it.courseId }.toSet()

        AlertDialog(
            onDismissRequest = { selectedStudentForCourses = null },
            containerColor = Navy700,
            title = {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                    Text("صلاحيات الكورسات", color = Gold500, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("الطالب: ${student.name}", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Bulk Grant / Revoke Controls (فتح الكل / قفل الكل)
                    Surface(
                        color = Navy800,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "إجراءات سريعة لجميع الكورسات:",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.repository.grantAllCoursesToStudent(student.id)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("فتح الكل ✓", color = Navy900, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }

                                Button(
                                    onClick = {
                                        viewModel.repository.revokeAllCoursesFromStudent(student.id)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoseBg),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("قفل الكل ✕", color = RoseRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    Text(
                        "التحكم في كل كورس على حدة:",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(courses.sortedBy { it.displayOrder }) { course ->
                            val isAssigned = course.id in studentAssignedIds

                            Surface(
                                color = Navy800,
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isAssigned || course.isOpenToAll) EmeraldDark else Navy600
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Action buttons: Open / Close specific course
                                    if (course.isOpenToAll) {
                                        Surface(
                                            color = EmeraldDark,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                "مفتوح للجميع",
                                                color = EmeraldGreen,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                            )
                                        }
                                    } else {
                                        if (isAssigned) {
                                            Button(
                                                onClick = {
                                                    viewModel.repository.closeCourseForStudent(student.id, course.id)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = RoseBg),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(6.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Text("قفل الكورس", color = RoseRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    viewModel.repository.openCourseForStudent(student.id, course.id)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                shape = RoundedCornerShape(6.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Text("فتح الكورس", color = Navy900, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    // Course Title & Status
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(course.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            text = when {
                                                course.isOpenToAll -> "متاح لجميع الطلاب تلقائياً"
                                                isAssigned -> "✓ مفتوح ومتاح لهذا الطالب"
                                                else -> "🔒 مغلق عن هذا الطالب"
                                            },
                                            color = when {
                                                course.isOpenToAll -> EmeraldGreen
                                                isAssigned -> EmeraldGreen
                                                else -> TextSecondary
                                            },
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedStudentForCourses = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إغلاق", color = Navy900, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

// 3. Courses Section (Matches Screenshot 6)
@Composable
fun AdminCoursesSection(viewModel: SevenProViewModel) {
    val courses by viewModel.courses.collectAsState()
    val lessons by viewModel.lessons.collectAsState()

    var showCourseDialog by remember { mutableStateOf(false) }
    var courseToEdit by remember { mutableStateOf<Course?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        courseToEdit = null
                        showCourseDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ إضافة كورس", color = Navy900, fontWeight = FontWeight.Bold)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("الكورسات", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${courses.size} كورس · استخدم الأسهم لإعادة الترتيب",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        items(courses.sortedBy { it.displayOrder }) { course ->
            val courseLessons = lessons.filter { it.courseId == course.id }

            Surface(
                color = Navy700,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    // Cover Preview Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        val coverRes = when (course.imageUrl) {
                            "cover_conversation" -> R.drawable.cover_conversation
                            else -> R.drawable.cover_beginner
                        }
                        Image(
                            painter = painterResource(id = coverRes),
                            contentDescription = course.title,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Surface(
                                    color = if (course.isPublished) EmeraldDark else RoseBg,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (course.isPublished) "منشور" else "مسودة",
                                        color = if (course.isPublished) EmeraldGreen else RoseRed,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Surface(
                                    color = if (course.isOpenToAll) EmeraldDark.copy(alpha = 0.8f) else RoseBg.copy(alpha = 0.8f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (course.isOpenToAll) "مفتوح للجميع" else "مغلق",
                                        color = if (course.isOpenToAll) EmeraldGreen else RoseRed,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = course.title,
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = course.description,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 2,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (course.isOpenToAll) EmeraldDark else RoseBg,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (course.isOpenToAll) "مفتوح للجميع" else "قفل الكورس (تفعيل فردي)",
                                    color = if (course.isOpenToAll) EmeraldGreen else RoseRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "${courseLessons.size} درس",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Navy600)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Action Buttons Bar (Screenshot 6 Exact Match)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Reorder Arrows
                            Row {
                                IconButton(
                                    onClick = { viewModel.repository.reorderCourse(course.id, moveUp = true) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = "أعلى", tint = Gold400, modifier = Modifier.size(18.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.repository.reorderCourse(course.id, moveUp = false) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = "أسفل", tint = Gold400, modifier = Modifier.size(18.dp))
                                }
                            }

                            // Duplicate, Edit, Lessons, Delete
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { viewModel.repository.duplicateCourse(course.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("نسخ", color = TextPrimary, fontSize = 11.sp)
                                }

                                Button(
                                    onClick = {
                                        courseToEdit = course
                                        showCourseDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("تعديل", color = TextPrimary, fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { viewModel.setAdminSection(AdminSection.LESSONS) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("الدروس", color = TextPrimary, fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { viewModel.repository.deleteCourse(course.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoseBg),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("حذف", color = RoseRed, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCourseDialog) {
        var editTitle by remember { mutableStateOf(courseToEdit?.title ?: "") }
        var editDesc by remember { mutableStateOf(courseToEdit?.description ?: "") }
        var editCover by remember { mutableStateOf(courseToEdit?.imageUrl ?: "cover_beginner") }
        var editIsOpenToAll by remember { mutableStateOf(courseToEdit?.isOpenToAll ?: false) }
        var isPub by remember { mutableStateOf(courseToEdit?.isPublished ?: true) }

        AlertDialog(
            onDismissRequest = { showCourseDialog = false },
            containerColor = Navy700,
            title = { Text(if (courseToEdit == null) "إضافة كورس جديد" else "تعديل الكورس", color = TextPrimary, textAlign = TextAlign.Right) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("عنوان الكورس", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editDesc,
                        onValueChange = { editDesc = it },
                        label = { Text("وصف الكورس", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("صورة الغلاف:", color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = editCover == "cover_beginner",
                                onClick = { editCover = "cover_beginner" },
                                label = { Text("مبتدئين") }
                            )
                            FilterChip(
                                selected = editCover == "cover_conversation",
                                onClick = { editCover = "cover_conversation" },
                                label = { Text("محادثة") }
                            )
                        }
                    }

                    HorizontalDivider(color = Navy600)

                    // Access Control Section (إتاحة الكورس للطلاب)
                    Surface(
                        color = Navy800,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Gold500.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = if (editIsOpenToAll) EmeraldDark else RoseBg,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (editIsOpenToAll) "متاح للجميع" else "مغلق افتراضياً",
                                        color = if (editIsOpenToAll) EmeraldGreen else RoseRed,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = "إتاحة الكورس للطلاب",
                                    color = Gold400,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = if (editIsOpenToAll) 
                                    "الكورس متاح لكافة الطلاب المسجلين فورياً دون الحاجة لتفعيل يدوي."
                                else 
                                    "الكورس مغلق للطلاب افتراضياً ويحتاج لمنح صلاحية فردية لكل طالب من قائمة الطلاب.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Open / Closed Control (فتح الكورس للجميع / قفل الكورس)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = !editIsOpenToAll,
                                    onClick = { editIsOpenToAll = false },
                                    label = { Text("قفل الكورس (مغلق)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = RoseBg,
                                        selectedLabelColor = RoseRed
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = editIsOpenToAll,
                                    onClick = { editIsOpenToAll = true },
                                    label = { Text("فتح الكورس للجميع", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldDark,
                                        selectedLabelColor = EmeraldGreen
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editTitle.isNotBlank()) {
                            val newOrUpdated = Course(
                                id = courseToEdit?.id ?: UUID.randomUUID().toString(),
                                title = editTitle,
                                description = editDesc,
                                imageUrl = editCover,
                                isOpenToAll = editIsOpenToAll,
                                isPublished = isPub,
                                displayOrder = courseToEdit?.displayOrder ?: 0
                            )
                            viewModel.repository.saveCourse(newOrUpdated)
                            showCourseDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("حفظ", color = Navy900, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCourseDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }
}

// 4. Lessons and Videos Section
@Composable
fun AdminLessonsSection(viewModel: SevenProViewModel) {
    val courses by viewModel.courses.collectAsState()
    val lessons by viewModel.lessons.collectAsState()

    var selectedCourseId by remember { mutableStateOf(courses.firstOrNull()?.id ?: "") }
    var showLessonDialog by remember { mutableStateOf(false) }
    var lessonToEdit by remember { mutableStateOf<Lesson?>(null) }

    val courseLessons = lessons.filter { it.courseId == selectedCourseId }.sortedBy { it.displayOrder }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        lessonToEdit = null
                        showLessonDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ إضافة درس جديد", color = Navy900, fontWeight = FontWeight.Bold)
                }

                Text("الدروس والفيديوهات", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Course Selector
            Text("اختر الكورس لعرض وتعديل دروسه:", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                courses.forEach { c ->
                    FilterChip(
                        selected = selectedCourseId == c.id,
                        onClick = { selectedCourseId = c.id },
                        label = { Text(c.title) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Gold500,
                            selectedLabelColor = Navy900
                        )
                    )
                }
            }
        }

        items(courseLessons) { lesson ->
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = Gold600.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = lesson.duration,
                                color = Gold400,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Text(lesson.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "رابط الفيديو: ${lesson.videoUrl}",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Navy600)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row {
                            IconButton(
                                onClick = { viewModel.repository.reorderLesson(lesson.id, true) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Gold400, modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                onClick = { viewModel.repository.reorderLesson(lesson.id, false) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Gold400, modifier = Modifier.size(16.dp))
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(
                                onClick = {
                                    lessonToEdit = lesson
                                    showLessonDialog = true
                                }
                            ) {
                                Text("تعديل الفيديو والرابط", color = Gold500, fontSize = 12.sp)
                            }
                            IconButton(
                                onClick = { viewModel.repository.deleteLesson(lesson.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = RoseRed, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLessonDialog) {
        var editTitle by remember { mutableStateOf(lessonToEdit?.title ?: "") }
        var editDuration by remember { mutableStateOf(lessonToEdit?.duration ?: "10:00") }
        var editVideoUrl by remember { mutableStateOf(lessonToEdit?.videoUrl ?: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") }

        AlertDialog(
            onDismissRequest = { showLessonDialog = false },
            containerColor = Navy700,
            title = { Text(if (lessonToEdit == null) "إضافة درس جديد" else "تعديل بيانات الدرس والفيديو", color = TextPrimary, textAlign = TextAlign.Right) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("عنوان الدرس", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editDuration,
                        onValueChange = { editDuration = it },
                        label = { Text("المدة (مثال: 08:20)", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editVideoUrl,
                        onValueChange = { editVideoUrl = it },
                        label = { Text("رابط الفيديو (MP4 / HLS)", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editTitle.isNotBlank() && editVideoUrl.isNotBlank()) {
                            val newOrUpdated = Lesson(
                                id = lessonToEdit?.id ?: UUID.randomUUID().toString(),
                                courseId = selectedCourseId,
                                title = editTitle,
                                duration = editDuration,
                                videoUrl = editVideoUrl,
                                displayOrder = lessonToEdit?.displayOrder ?: 0,
                                status = "published"
                            )
                            viewModel.repository.saveLesson(newOrUpdated)
                            showLessonDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("حفظ", color = Navy900, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLessonDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }
}

// 5. Permissions Section (الصلاحيات)
@Composable
fun AdminPermissionsSection(viewModel: SevenProViewModel) {
    val students by viewModel.students.collectAsState()
    val courses by viewModel.courses.collectAsState()
    val assignments by viewModel.assignments.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("مصفوفة الصلاحيات وتعيين الكورسات للطلاب", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Text("يتم تطبيق الصلاحيات بشكل صارم، ولا يمكن للطالب الوصول إلا للكورسات المحددة له هنا.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(students.filter { it.role == UserRole.STUDENT }) { student ->
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "${student.name} (${student.email})",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    courses.forEach { course ->
                        val isAssigned = assignments.any { it.studentId == student.id && it.courseId == course.id }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.repository.toggleCourseAssignment(student.id, course.id) }
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Switch(
                                checked = isAssigned,
                                onCheckedChange = { viewModel.repository.toggleCourseAssignment(student.id, course.id) },
                                colors = SwitchDefaults.colors(checkedThumbColor = Navy900, checkedTrackColor = Gold500)
                            )
                            Text(course.title, color = if (isAssigned) TextPrimary else TextMuted, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// 6. Appearance Section (المظهر)
@Composable
fun AdminAppearanceSection(viewModel: SevenProViewModel) {
    val appearance by viewModel.appearance.collectAsState()

    var headline by remember { mutableStateOf(appearance.heroHeadline) }
    var welcome by remember { mutableStateOf(appearance.welcomeText) }
    var savedAlert by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("إعدادات المظهر والواجهة الرئيسية", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Text("تعديل النصوص والشعارات التي تظهر للطلاب فوراً دون إعادة بناء التطبيق.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = headline,
                        onValueChange = { headline = it },
                        label = { Text("عنوان الشاشة الرئيسية", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = welcome,
                        onValueChange = { welcome = it },
                        label = { Text("النص الترحيبي والوصفي", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            viewModel.repository.updateAppearance(
                                appearance.copy(heroHeadline = headline, welcomeText = welcome)
                            )
                            savedAlert = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ التغييرات", color = Navy900, fontWeight = FontWeight.Bold)
                    }

                    if (savedAlert) {
                        Text("✓ تم حفظ المظهر وتحديثه في واجهة الطلاب بنجاح", color = EmeraldGreen, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

// 7. Settings Section (الإعدادات)
@Composable
fun AdminSettingsSection(viewModel: SevenProViewModel) {
    val appSettings by viewModel.appSettings.collectAsState()

    var regEnabled by remember { mutableStateOf(appSettings.registrationEnabled) }
    var maintMode by remember { mutableStateOf(appSettings.maintenanceMode) }
    var maintMsg by remember { mutableStateOf(appSettings.maintenanceMessage) }
    var minVersion by remember { mutableStateOf(appSettings.minSupportedVersion) }
    var latestVersion by remember { mutableStateOf(appSettings.appVersion) }
    var forceUpdate by remember { mutableStateOf(appSettings.forceUpdate) }
    var updateMsg by remember { mutableStateOf(appSettings.updateMessage) }
    var savedSuccess by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("إعدادات المنصة والتحكم في الإصدارات", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Registration Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = regEnabled,
                            onCheckedChange = {
                                regEnabled = it
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Navy900, checkedTrackColor = Gold500)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("السماح بالتسجيل الذاتي للطلاب", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("عند التفعيل، يمكن للطلاب إنشاء حسابات وتفعيلها فورياً", color = TextSecondary, fontSize = 11.sp)
                        }
                    }

                    HorizontalDivider(color = Navy600)

                    // Maintenance Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = maintMode,
                            onCheckedChange = {
                                maintMode = it
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Navy900, checkedTrackColor = RoseRed)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("وضع الصيانة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("منع الطلاب من الدخول وعرض رسالة الصيانة", color = TextSecondary, fontSize = 11.sp)
                        }
                    }

                    if (maintMode) {
                        OutlinedTextField(
                            value = maintMsg,
                            onValueChange = { maintMsg = it },
                            label = { Text("رسالة الصيانة", color = TextSecondary) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    HorizontalDivider(color = Navy600)

                    // App Version Control Section
                    Text("التحكم في إصدارات التطبيق والتحديث الإجباري", color = Gold400, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = minVersion,
                            onValueChange = { minVersion = it },
                            label = { Text("أدنى إصدار مدعوم", color = TextSecondary) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = latestVersion,
                            onValueChange = { latestVersion = it },
                            label = { Text("أحدث إصدار متاح", color = TextSecondary) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = forceUpdate,
                            onCheckedChange = { forceUpdate = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Navy900, checkedTrackColor = Gold500)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("إلزام الطلاب بالتحديث الفوري", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("منع الدخول حتى يتم التحديث لأحدث إصدار", color = TextSecondary, fontSize = 11.sp)
                        }
                    }

                    OutlinedTextField(
                        value = updateMsg,
                        onValueChange = { updateMsg = it },
                        label = { Text("رسالة إشعار التحديث", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            viewModel.repository.updateAppSettings(
                                appSettings.copy(
                                    registrationEnabled = regEnabled,
                                    maintenanceMode = maintMode,
                                    maintenanceMessage = maintMsg,
                                    minSupportedVersion = minVersion,
                                    appVersion = latestVersion,
                                    forceUpdate = forceUpdate,
                                    updateMessage = updateMsg
                                )
                            )
                            savedSuccess = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ وتطبيق كافة الإعدادات", color = Navy900, fontWeight = FontWeight.Bold)
                    }

                    if (savedSuccess) {
                        Text("✓ تم تطبيق الإعدادات وتحديث حالة السيرفر بنجاح", color = EmeraldGreen, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

// 8. Security & Backup Section (الأمان والنسخ الاحتياطي)
@Composable
fun AdminSecuritySection(viewModel: SevenProViewModel) {
    val auditLogs by viewModel.auditLogs.collectAsState()
    var backupJsonDialog by remember { mutableStateOf<String?>(null) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreInputText by remember { mutableStateOf("") }
    var restoreFeedback by remember { mutableStateOf<String?>(null) }
    var sessionTerminatedAlert by remember { mutableStateOf(false) }

    // Pagination for Audit Logs
    var auditPage by remember { mutableIntStateOf(1) }
    val pageSize = 5
    val totalAuditPages = ((auditLogs.size + pageSize - 1) / pageSize).coerceAtLeast(1)
    val paginatedLogs = auditLogs.drop((auditPage - 1) * pageSize).take(pageSize)

    // Backup JSON Dialog
    if (backupJsonDialog != null) {
        AlertDialog(
            onDismissRequest = { backupJsonDialog = null },
            containerColor = Navy800,
            title = {
                Text("نسخة احتياطية مكتملة (JSON Snapshot)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("تم إنشاء النسخة الاحتياطية بنجاح ومطابقة جداول MongoDB:", color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = Navy900,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp)
                    ) {
                        Text(
                            text = backupJsonDialog ?: "",
                            color = Gold400,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { backupJsonDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("إغلاق", color = Navy900, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            containerColor = Navy800,
            title = {
                Text("استعادة نسخة احتياطية", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الصق محتوى النسخة الاحتياطية (JSON) للاستعادة ومطابقة البنية:", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        value = restoreInputText,
                        onValueChange = { restoreInputText = it },
                        label = { Text("بيانات النسخة الاحتياطية", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                        maxLines = 6
                    )
                    if (restoreFeedback != null) {
                        Text(
                            text = restoreFeedback ?: "",
                            color = if (restoreFeedback!!.startsWith("✓")) EmeraldGreen else RoseRed,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val res = viewModel.repository.restoreDatabaseFromBackup(restoreInputText)
                        res.onSuccess {
                            restoreFeedback = "✓ $it"
                        }.onFailure {
                            restoreFeedback = it.message ?: "فشل الاستعادة"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("استعادة وتحقق", color = Navy900, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("الأمان وسجلات التدقيق والنسخ الاحتياطي", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("النسخ الاحتياطي والاستعادة الفورية", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    Text("إنشاء نسخة احتياطية حقيقية لقاعدة بيانات MongoDB أو استعادتها.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                backupJsonDialog = viewModel.repository.exportDatabaseBackup()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تصدير JSON", color = Navy900, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                restoreFeedback = null
                                restoreInputText = ""
                                showRestoreDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Navy600),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("استعادة نسخة", color = TextPrimary)
                        }
                    }

                    HorizontalDivider(color = Navy600)

                    // Session termination
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                viewModel.repository.terminateAllAdminSessions()
                                sessionTerminatedAlert = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoseRed.copy(alpha = 0.85f))
                        ) {
                            Text("إنهاء الجلسات", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("تسجيل الخروج من كافة الأجهزة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("إبطال جميع الجلسات النشطة للمشرفين فورياً", color = TextSecondary, fontSize = 11.sp)
                        }
                    }

                    if (sessionTerminatedAlert) {
                        Text("✓ تم إنهاء وإبطال كافة الجلسات النشطة بنجاح", color = EmeraldGreen, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }

        // Paginated Audit Logs Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pagination Navigation Controls
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (auditPage < totalAuditPages) auditPage++ },
                        enabled = auditPage < totalAuditPages,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "التالي", tint = if (auditPage < totalAuditPages) Gold500 else TextMuted)
                    }
                    Text("$auditPage / $totalAuditPages", color = TextSecondary, fontSize = 12.sp)
                    IconButton(
                        onClick = { if (auditPage > 1) auditPage-- },
                        enabled = auditPage > 1,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "السابق", tint = if (auditPage > 1) Gold500 else TextMuted)
                    }
                }

                Text("سجل العمليات والتدقيق (${auditLogs.size})", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        items(paginatedLogs) { log ->
            Surface(
                color = Navy700,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(log.adminEmail, color = Gold400, fontSize = 11.sp)
                        Text(log.action, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(log.details, color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

