package com.example.ui.student

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.Course
import com.example.data.Lesson
import com.example.data.UserRole
import com.example.ui.components.VideoPlayer
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen
import com.example.viewmodel.SevenProViewModel

@Composable
fun LoginScreen(viewModel: SevenProViewModel) {
    var email by remember { mutableStateOf("7pro7777@gmail.com") }
    var password by remember { mutableStateOf("student123") }
    var isRegisterMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    // Reset password state fields
    var resetInputEmail by remember { mutableStateOf("") }
    var resetInputCode by remember { mutableStateOf("") }
    var resetInputNewPass by remember { mutableStateOf("") }

    val resetStep by viewModel.resetStep.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val authSuccess by viewModel.authSuccessMessage.collectAsState()

    // Forgot Password Dialog
    if (showForgotPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showForgotPasswordDialog = false },
            containerColor = Navy800,
            title = {
                Text(
                    text = if (resetStep == 1) "إعادة تعيين كلمة المرور" else "إدخال رمز التحقق وكلمة المرور الجديدة",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (authError != null) {
                        Text(
                            text = authError ?: "",
                            color = RoseRed,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (authSuccess != null) {
                        Text(
                            text = authSuccess ?: "",
                            color = EmeraldGreen,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (resetStep == 1) {
                        Text(
                            text = "أدخل بريدك الإلكتروني المسجل لإرسال رمز التحقق السري.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = resetInputEmail,
                            onValueChange = { resetInputEmail = it },
                            label = { Text("البريد الإلكتروني", color = TextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text(
                            text = "تم إرسال رمز تحقق مكون من 6 أرقام إلى بريدك. أدخل الرمز وكلمة المرور الجديدة.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = resetInputCode,
                            onValueChange = { resetInputCode = it },
                            label = { Text("رمز التحقق (6 أرقام)", color = TextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = resetInputNewPass,
                            onValueChange = { resetInputNewPass = it },
                            label = { Text("كلمة المرور الجديدة", color = TextSecondary) },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetStep == 1) {
                            if (resetInputEmail.isNotBlank()) {
                                viewModel.submitResetEmail(resetInputEmail)
                            }
                        } else {
                            if (resetInputCode.isNotBlank() && resetInputNewPass.isNotBlank()) {
                                viewModel.submitResetPassword(resetInputCode, resetInputNewPass)
                                if (authError == null) {
                                    showForgotPasswordDialog = false
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text(
                        text = if (resetStep == 1) "إرسال الرمز" else "تأكيد وتغيير كلمة المرور",
                        color = Navy900,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPasswordDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Hero Background
        Image(
            painter = painterResource(id = R.drawable.bg_login_hero),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Dark Overlay Gradient
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Navy900.copy(alpha = 0.85f),
                            Navy900.copy(alpha = 0.95f),
                            Navy900
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.weight(0.5f))

            // 7PRO Logo
            Text(
                text = "7PRO",
                color = Gold500,
                fontSize = 42.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "طوّر لغتك الإنجليزية مع نخبة من الدورات الاحترافية",
                color = TextSecondary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Form Title
            Text(
                text = if (isRegisterMode) "إنشاء حساب جديد" else "تسجيل الدخول",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Right
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (authError != null) {
                Surface(
                    color = RoseBg.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = authError ?: "",
                        color = RoseRed,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Right
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (authSuccess != null) {
                Surface(
                    color = EmeraldBg.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = authSuccess ?: "",
                        color = EmeraldGreen,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Right
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (isRegisterMode) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الاسم الكامل", color = TextSecondary) },
                    trailingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = TextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Gold500,
                        unfocusedBorderColor = Navy500,
                        focusedContainerColor = Navy700,
                        unfocusedContainerColor = Navy700,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("البريد الإلكتروني", color = TextSecondary) },
                trailingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold500,
                    unfocusedBorderColor = Navy500,
                    focusedContainerColor = Navy700,
                    unfocusedContainerColor = Navy700,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("كلمة المرور", color = TextSecondary) },
                trailingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = TextSecondary) },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold500,
                    unfocusedBorderColor = Navy500,
                    focusedContainerColor = Navy700,
                    unfocusedContainerColor = Navy700,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            if (!isRegisterMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.startForgotPassword()
                            showForgotPasswordDialog = true
                        },
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = "نسيت كلمة المرور؟",
                        color = Gold400,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = {
                    if (isRegisterMode) {
                        viewModel.register(name, email, password)
                    } else {
                        viewModel.login(email, password)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (isRegisterMode) "إنشاء الحساب" else "دخول",
                        color = Navy900,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                        contentDescription = null,
                        tint = Navy900,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.clickable {
                    isRegisterMode = !isRegisterMode
                }
            ) {
                Text(
                    text = if (isRegisterMode) "لديك حساب بالفعل؟ " else "ليس لديك حساب؟ ",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
                Text(
                    text = if (isRegisterMode) "تسجيل الدخول" else "أنشئ حساباً",
                    color = Gold500,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Quick Demo Switcher helper chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SuggestionChip(
                    onClick = {
                        email = "7pro7777@gmail.com"
                        password = "student123"
                    },
                    label = { Text("طالب تجريبي", color = Gold400, fontSize = 11.sp) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Navy700)
                )
                SuggestionChip(
                    onClick = {
                        email = "admin@7pro.com"
                        password = "admin123"
                    },
                    label = { Text("مدير 7PRO", color = Gold500, fontSize = 11.sp) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Navy700)
                )
            }
        }
    }
}

@Composable
fun StudentMainScaffold(
    viewModel: SevenProViewModel,
    content: @Composable (PaddingValues) -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    Scaffold(
        containerColor = Navy800,
        bottomBar = {
            NavigationBar(
                containerColor = Navy900,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.STUDENT_HOME,
                    onClick = { viewModel.navigateTo(AppScreen.STUDENT_HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                    label = { Text("الرئيسية") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Gold500,
                        selectedTextColor = Gold500,
                        indicatorColor = Navy700,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.STUDENT_MY_COURSES,
                    onClick = { viewModel.navigateTo(AppScreen.STUDENT_MY_COURSES) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = "دوراتي") },
                    label = { Text("دوراتي") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Gold500,
                        selectedTextColor = Gold500,
                        indicatorColor = Navy700,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
            }
        }
    ) { padding ->
        content(padding)
    }
}

@Composable
fun StudentHomeScreen(viewModel: SevenProViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val appearance by viewModel.appearance.collectAsState()
    val courses by viewModel.courses.collectAsState()
    val assignments by viewModel.assignments.collectAsState()
    
    val allCourses = remember(courses) { 
        courses.filter { it.isPublished && !it.isHidden }.sortedBy { it.displayOrder } 
    }

    var lockedCourseDialogCourse by remember { mutableStateOf<Course?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        item {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 7PRO Badge pill
                Surface(
                    color = Navy700,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                    modifier = Modifier.clickable {
                        // Quick switch to Admin if user is admin
                        viewModel.switchRoleToAdmin()
                    }
                ) {
                    Text(
                        text = "7PRO",
                        color = Gold500,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                // Greeting on right (RTL)
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "أهلاً بك",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = currentUser?.name ?: "طالب",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Headline
            Text(
                text = appearance.heroHeadline,
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = appearance.welcomeText,
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))
        }

        if (allCourses.isEmpty()) {
            item {
                Surface(
                    color = Navy700,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.School,
                            contentDescription = null,
                            tint = Gold500,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد كورسات متاحة حالياً",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        } else {
            items(allCourses) { course ->
                val hasAccess = viewModel.canAccessCourse(course.id)
                CourseCard(
                    course = course,
                    hasAccess = hasAccess,
                    viewModel = viewModel,
                    onClick = { 
                        if (hasAccess) {
                            viewModel.selectCourse(course.id)
                        } else {
                            lockedCourseDialogCourse = course
                        }
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Locked Course Information Dialog
    if (lockedCourseDialogCourse != null) {
        val c = lockedCourseDialogCourse!!
        AlertDialog(
            onDismissRequest = { lockedCourseDialogCourse = null },
            containerColor = Navy700,
            icon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Gold500,
                    modifier = Modifier.size(40.dp)
                )
            },
            title = {
                Text(
                    text = "الكورس مغلق",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "كورس: ${c.title}",
                        color = Gold400,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "هذا الكورس غير متاح لحسابك حالياً. يرجى التواصل مع إدارة 7PRO لتفعيل اشتراكك في الكورس والبدء في مشاهدة الدروس.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { lockedCourseDialogCourse = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("حسناً", color = Navy900, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun CourseCard(
    course: Course,
    hasAccess: Boolean,
    viewModel: SevenProViewModel,
    onClick: () -> Unit
) {
    val lessons by viewModel.lessons.collectAsState()
    val courseLessons = lessons.filter { it.courseId == course.id && it.status == "published" }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        color = Navy700,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp, 
            if (hasAccess) Navy500 else Gold500.copy(alpha = 0.3f)
        )
    ) {
        Column {
            // Course Image Box with Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                val coverRes = when (course.imageUrl) {
                    "cover_conversation" -> R.drawable.cover_conversation
                    else -> R.drawable.cover_beginner
                }
                Image(
                    painter = painterResource(id = coverRes),
                    contentDescription = course.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Dark gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    if (hasAccess) Color.Transparent else Navy900.copy(alpha = 0.6f),
                                    Navy700.copy(alpha = 0.95f)
                                )
                            )
                        )
                )

                // Top Access Badge
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (hasAccess) EmeraldDark.copy(alpha = 0.9f) else RoseBg.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp, 
                            if (hasAccess) EmeraldGreen.copy(alpha = 0.6f) else RoseRed.copy(alpha = 0.6f)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = if (hasAccess) Icons.Default.CheckCircle else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (hasAccess) EmeraldGreen else RoseRed,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (hasAccess) "متاح" else "مغلق",
                                color = if (hasAccess) EmeraldGreen else RoseRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Center Lock Icon if locked
                if (!hasAccess) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Navy900.copy(alpha = 0.8f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Gold500.copy(alpha = 0.6f)),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "كورس مغلق",
                                    tint = Gold400,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Details
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = course.title,
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = course.description,
                    color = TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 2,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (hasAccess) "اضغط لبدء المشاهدة" else "يتطلب تفعيل من الإدارة",
                        color = if (hasAccess) EmeraldGreen else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasAccess) Icons.Default.PlayCircle else Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (hasAccess) Gold500 else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${courseLessons.size} درس",
                            color = Gold400,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StudentMyCoursesScreen(viewModel: SevenProViewModel) {
    val assignedCourses = remember(viewModel) { viewModel.getAssignedCoursesForCurrentStudent() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        item {
            Text(
                text = "دوراتي المفعلة",
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (assignedCourses.isEmpty()) {
            item {
                Surface(
                    color = Navy700,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = Gold500,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد دورات مفعلة لحسابك حالياً",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "عندما تقوم الإدارة بفتح أي كورس لحسابك، سيظهر هنا مباشرة مع شريط متابعة التقدم.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(assignedCourses) { course ->
                val (completed, total) = viewModel.getCourseProgress(course.id)
                val progressPercent = if (total > 0) ((completed.toFloat() / total) * 100).toInt() else 0

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { viewModel.selectCourse(course.id) },
                    color = Navy700,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Navy500)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = EmeraldDark,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "متاح",
                                    color = EmeraldGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = course.title,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Right
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "$completed من $total درس مكتمل",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "$progressPercent%",
                                color = Gold500,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LinearProgressIndicator(
                            progress = { if (total > 0) completed.toFloat() / total else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Gold500,
                            trackColor = Navy600
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun CourseDetailScreen(viewModel: SevenProViewModel) {
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val courses by viewModel.courses.collectAsState()
    val lessons by viewModel.lessons.collectAsState()

    val course = courses.find { it.id == selectedCourseId }
    if (course == null) return

    val hasAccess = viewModel.canAccessCourse(course.id)
    val courseLessons = lessons.filter { it.courseId == selectedCourseId && it.status == "published" }.sortedBy { it.displayOrder }

    val (completedCount, totalCount) = viewModel.getCourseProgress(course.id)
    val progressPct = if (totalCount > 0) ((completedCount.toFloat() / totalCount) * 100).toInt() else 0

    Scaffold(
        containerColor = Navy800,
        topBar = {
            // Header Image with Back Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            ) {
                val coverRes = when (course.imageUrl) {
                    "cover_conversation" -> R.drawable.cover_conversation
                    else -> R.drawable.cover_beginner
                }
                Image(
                    painter = painterResource(id = coverRes),
                    contentDescription = course.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Navy900.copy(alpha = 0.5f), Navy800)
                            )
                        )
                )

                // Top Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (hasAccess) EmeraldDark.copy(alpha = 0.9f) else RoseBg.copy(alpha = 0.9f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (hasAccess) "متاح" else "مغلق",
                            color = if (hasAccess) EmeraldGreen else RoseRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.STUDENT_HOME) },
                        modifier = Modifier
                            .background(Navy900.copy(alpha = 0.6f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = TextPrimary
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        if (!hasAccess) {
            // Access Restricted Screen for locked course
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = RoseBg,
                    modifier = Modifier.size(72.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = RoseRed,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "هذا الكورس مغلق حالياً",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "يرجى التواصل مع إدارة 7PRO لتفعيل اشتراكك والوصول لكافة دروس وفيديوهات هذا الكورس.",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.STUDENT_HOME) },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("العودة للرئيسية", color = Navy900, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                item {
                    Text(
                        text = course.title,
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = course.description,
                        color = TextSecondary,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Progress Card (Screenshot 2 Match)
                    Surface(
                        color = Navy700,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Navy500),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "تقدمك في الدورة",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "$progressPct%",
                                    color = Gold500,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LinearProgressIndicator(
                                progress = { if (totalCount > 0) completedCount.toFloat() / totalCount else 0f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Gold500,
                                trackColor = Navy600
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "$completedCount من $totalCount درس مكتمل",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Big Golden Action Button
                    Button(
                        onClick = {
                            val firstUnfinished = courseLessons.find { !viewModel.isLessonCompleted(course.id, it.id) } 
                                ?: courseLessons.firstOrNull()
                            if (firstUnfinished != null) {
                                viewModel.selectLesson(course.id, firstUnfinished.id)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold500),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (completedCount > 0) "متابعة الدورة" else "ابدأ الدورة",
                                color = Navy900,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Navy900
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Section Header: الدروس
                    Text(
                        text = "الدروس",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                }

                itemsIndexed(courseLessons) { index, lesson ->
                    val isCompleted = viewModel.isLessonCompleted(course.id, lesson.id)

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectLesson(course.id, lesson.id) },
                        color = Navy700,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Navy500)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Play icon on left
                            Icon(
                                imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.PlayCircle,
                                contentDescription = null,
                                tint = if (isCompleted) EmeraldGreen else Gold500,
                                modifier = Modifier.size(24.dp)
                            )

                            // Title and duration
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 12.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    text = lesson.title,
                                    color = TextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Right
                                )
                                Text(
                                    text = lesson.duration,
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            // Numbered Badge on right
                            Surface(
                                color = Gold600.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Gold500.copy(alpha = 0.5f)),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${index + 1}",
                                        color = Gold400,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
fun LessonPlayerScreen(viewModel: SevenProViewModel) {
    val selectedCourseId by viewModel.selectedCourseId.collectAsState()
    val selectedLessonId by viewModel.selectedLessonId.collectAsState()
    val courses by viewModel.courses.collectAsState()
    val lessons by viewModel.lessons.collectAsState()

    val course = courses.find { it.id == selectedCourseId }
    val lesson = lessons.find { it.id == selectedLessonId }

    if (course == null || lesson == null) return

    val hasAccess = viewModel.canAccessCourse(course.id)
    val courseLessons = lessons.filter { it.courseId == course.id && it.status == "published" }.sortedBy { it.displayOrder }
    val currentIndex = courseLessons.indexOfFirst { it.id == lesson.id }
    val isCompleted = viewModel.isLessonCompleted(course.id, lesson.id)

    Scaffold(
        containerColor = Navy800,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Navy900)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.COURSE_DETAIL) }
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = TextPrimary
                    )
                }

                Text(
                    text = course.title,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.size(36.dp))
            }
        }
    ) { innerPadding ->
        if (!hasAccess) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = RoseRed,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "هذا الدرس مغلق",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "يرجى التواصل مع إدارة 7PRO لتفعيل اشتراكك في الكورس.",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.STUDENT_HOME) },
                    colors = ButtonDefaults.buttonColors(containerColor = Gold500)
                ) {
                    Text("العودة للرئيسية", color = Navy900, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                // Video Player
                VideoPlayer(
                    videoUrl = lesson.videoUrl,
                    onEnded = {
                        viewModel.toggleLessonCompleted(course.id, lesson.id)
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Lesson Title and Duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isCompleted) {
                        Surface(
                            color = EmeraldDark,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "مكتمل ✓",
                                color = EmeraldGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.width(10.dp))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = lesson.title,
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Right
                        )
                        Text(
                            text = lesson.duration,
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Complete Toggle Button
                OutlinedButton(
                    onClick = {
                        viewModel.toggleLessonCompleted(course.id, lesson.id)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isCompleted) EmeraldBg.copy(alpha = 0.2f) else Navy700
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isCompleted) EmeraldGreen else Gold500
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (isCompleted) "إلغاء التحديد كمكتمل" else "تحديد كمكتمل ✓",
                            color = if (isCompleted) EmeraldGreen else Gold500,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Navigation Buttons (Next / Prev)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Previous Button (Navy)
                    Button(
                        onClick = { viewModel.previousLesson(course.id, lesson.id) },
                        enabled = currentIndex > 0,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Navy700,
                            disabledContainerColor = Navy900
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Navy500)
                    ) {
                        Text(
                            text = "السابق >",
                            color = if (currentIndex > 0) TextPrimary else TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Next Button (Gold)
                    Button(
                        onClick = { viewModel.nextLesson(course.id, lesson.id) },
                        enabled = currentIndex < courseLessons.size - 1,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Gold500,
                            disabledContainerColor = GoldDark.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "الدرس التالي <",
                            color = if (currentIndex < courseLessons.size - 1) Navy900 else TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
