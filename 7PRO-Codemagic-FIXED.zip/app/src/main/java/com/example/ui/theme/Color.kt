package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 7PRO Brand Palette
val Navy900 = Color(0xFF070C15) // Deep background
val Navy800 = Color(0xFF0C1424) // Scaffold background
val Navy700 = Color(0xFF131D31) // Card background
val Navy600 = Color(0xFF1B2842) // Input & surface background
val Navy500 = Color(0xFF263757) // Border & divider

// Gold / Amber Accents
val Gold400 = Color(0xFFFBBF24)
val Gold500 = Color(0xFFF59E0B) // Primary button gold
val Gold600 = Color(0xFFD97706) // Darker gold accent
val GoldDark = Color(0xFF92400E)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Status Colors
val EmeraldGreen = Color(0xFF10B981)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldBg = Color(0xFF065F46)
val RoseRed = Color(0xFFEF4444)
val RoseBg = Color(0xFF7F1D1D)
val AmberPending = Color(0xFFF59E0B)
val BlueInfo = Color(0xFF38BDF8)

