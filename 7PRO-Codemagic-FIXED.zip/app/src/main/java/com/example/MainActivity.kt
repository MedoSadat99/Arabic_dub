package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.admin.AdminDashboardScreen
import com.example.ui.student.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.SevenProViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SevenProApp()
                }
            }
        }
    }
}

@Composable
fun SevenProApp(viewModel: SevenProViewModel = viewModel()) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    when (currentScreen) {
        AppScreen.LOGIN, AppScreen.REGISTER -> {
            LoginScreen(viewModel = viewModel)
        }
        AppScreen.STUDENT_HOME -> {
            StudentMainScaffold(viewModel = viewModel) { paddingValues ->
                Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                    StudentHomeScreen(viewModel = viewModel)
                }
            }
        }
        AppScreen.STUDENT_MY_COURSES -> {
            StudentMainScaffold(viewModel = viewModel) { paddingValues ->
                Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
                    StudentMyCoursesScreen(viewModel = viewModel)
                }
            }
        }
        AppScreen.COURSE_DETAIL -> {
            CourseDetailScreen(viewModel = viewModel)
        }
        AppScreen.LESSON_PLAYER -> {
            LessonPlayerScreen(viewModel = viewModel)
        }
        AppScreen.ADMIN_DASHBOARD -> {
            AdminDashboardScreen(viewModel = viewModel)
        }
    }
}

