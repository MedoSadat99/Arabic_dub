package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen {
    LOGIN,
    REGISTER,
    STUDENT_HOME,
    STUDENT_MY_COURSES,
    COURSE_DETAIL,
    LESSON_PLAYER,
    ADMIN_DASHBOARD
}

enum class AdminSection {
    DASHBOARD,
    STUDENTS,
    COURSES,
    LESSONS,
    PERMISSIONS,
    APPEARANCE,
    SETTINGS,
    SECURITY
}

class SevenProViewModel(
    val repository: SevenProRepository = SevenProRepository()
) : ViewModel() {

    private val _currentScreen = MutableStateFlow(AppScreen.STUDENT_HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _adminSection = MutableStateFlow(AdminSection.DASHBOARD)
    val adminSection: StateFlow<AdminSection> = _adminSection.asStateFlow()

    private val _selectedCourseId = MutableStateFlow<String?>(null)
    val selectedCourseId: StateFlow<String?> = _selectedCourseId.asStateFlow()

    private val _selectedLessonId = MutableStateFlow<String?>(null)
    val selectedLessonId: StateFlow<String?> = _selectedLessonId.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authSuccessMessage = MutableStateFlow<String?>(null)
    val authSuccessMessage: StateFlow<String?> = _authSuccessMessage.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Expose Repository flows
    val currentUser = repository.currentUser
    val students = repository.students
    val courses = repository.courses
    val lessons = repository.lessons
    val assignments = repository.assignments
    val progressList = repository.progressList
    val appearance = repository.appearance
    val appSettings = repository.appSettings
    val auditLogs = repository.auditLogs

    init {
        // If current user is null on launch, show Login screen
        if (currentUser.value == null) {
            _currentScreen.value = AppScreen.LOGIN
        }
    }

    fun navigateTo(screen: AppScreen) {
        _authError.value = null
        _authSuccessMessage.value = null
        _currentScreen.value = screen
    }

    fun setAdminSection(section: AdminSection) {
        _adminSection.value = section
    }

    fun selectCourse(courseId: String) {
        _selectedCourseId.value = courseId
        _currentScreen.value = AppScreen.COURSE_DETAIL
    }

    fun selectLesson(courseId: String, lessonId: String) {
        _selectedCourseId.value = courseId
        _selectedLessonId.value = lessonId
        _currentScreen.value = AppScreen.LESSON_PLAYER
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Auth actions
    fun login(email: String, pass: String) {
        _authError.value = null
        val result = repository.login(email, pass)
        result.onSuccess { user ->
            if (user.role == UserRole.ADMIN) {
                _currentScreen.value = AppScreen.ADMIN_DASHBOARD
            } else {
                _currentScreen.value = AppScreen.STUDENT_HOME
            }
        }.onFailure {
            _authError.value = it.message ?: "حدث خطأ أثناء تسجيل الدخول"
        }
    }

    fun register(name: String, email: String, pass: String) {
        _authError.value = null
        _authSuccessMessage.value = null
        val result = repository.registerStudent(name, email, pass)
        result.onSuccess {
            _authSuccessMessage.value = "تم إنشاء حسابك وتفعيله بنجاح! يمكنك الآن تسجيل الدخول مباشرة والبدء في التعلّم."
            _currentScreen.value = AppScreen.LOGIN
        }.onFailure {
            _authError.value = it.message ?: "فشل إنشاء الحساب"
        }
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = AppScreen.LOGIN
    }

    fun switchRoleToAdmin() {
        val adminUser = students.value.find { it.role == UserRole.ADMIN }
        if (adminUser != null) {
            repository.switchUser(adminUser)
            _currentScreen.value = AppScreen.ADMIN_DASHBOARD
        }
    }

    fun switchRoleToStudent() {
        val studentUser = students.value.find { it.role == UserRole.STUDENT && it.status == UserStatus.ACTIVE }
        if (studentUser != null) {
            repository.switchUser(studentUser)
            _currentScreen.value = AppScreen.STUDENT_HOME
        }
    }

    // Helper queries for UI
    fun getAvailableCoursesForStudent(): List<Course> {
        return courses.value
            .filter { it.isPublished && !it.isHidden }
            .sortedBy { it.displayOrder }
    }

    fun getAssignedCoursesForCurrentStudent(): List<Course> {
        val user = currentUser.value ?: return emptyList()
        if (user.role == UserRole.ADMIN) return courses.value.filter { !it.isHidden }.sortedBy { it.displayOrder }
        val assignedIds = assignments.value.filter { it.studentId == user.id }.map { it.courseId }.toSet()
        return courses.value
            .filter { it.isPublished && !it.isHidden && (it.isOpenToAll || it.id in assignedIds) }
            .sortedBy { it.displayOrder }
    }

    fun canAccessCourse(courseId: String): Boolean {
        val user = currentUser.value ?: return false
        if (user.role == UserRole.ADMIN) return true
        val course = courses.value.find { it.id == courseId } ?: return false
        if (!course.isPublished || course.isHidden) return false
        if (course.isOpenToAll) return true // متاح للجميع
        val assignedIds = assignments.value.filter { it.studentId == user.id }.map { it.courseId }.toSet()
        return course.id in assignedIds
    }

    // Password Reset Flows
    private val _resetStep = MutableStateFlow(1) // 1: Email, 2: Code & New Password
    val resetStep: StateFlow<Int> = _resetStep.asStateFlow()

    private val _resetEmail = MutableStateFlow("")
    val resetEmail: StateFlow<String> = _resetEmail.asStateFlow()

    private val _generatedDemoCode = MutableStateFlow<String?>(null)
    val generatedDemoCode: StateFlow<String?> = _generatedDemoCode.asStateFlow()

    fun startForgotPassword() {
        _resetStep.value = 1
        _resetEmail.value = ""
        _generatedDemoCode.value = null
        _authError.value = null
        _authSuccessMessage.value = null
    }

    fun submitResetEmail(email: String) {
        _authError.value = null
        val res = repository.requestPasswordReset(email)
        res.onSuccess { code ->
            _resetEmail.value = email.trim()
            _generatedDemoCode.value = code
            _resetStep.value = 2
            _authSuccessMessage.value = "تم إرسال رمز التحقق إلى بريدك الإلكتروني بنجاح (رمز التحقق للاختبار: $code)"
        }.onFailure {
            _authError.value = it.message ?: "البريد الإلكتروني غير مسجل"
        }
    }

    fun submitResetPassword(code: String, newPass: String) {
        _authError.value = null
        val res = repository.confirmPasswordReset(_resetEmail.value, code, newPass)
        res.onSuccess {
            _authSuccessMessage.value = "تمت إعادة تعيين كلمة المرور بنجاح! يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة."
            _resetStep.value = 1
            _generatedDemoCode.value = null
        }.onFailure {
            _authError.value = it.message ?: "فشل إعادة تعيين كلمة المرور"
        }
    }

    fun getCourseProgress(courseId: String, studentId: String? = currentUser.value?.id): Pair<Int, Int> {
        if (studentId == null) return 0 to 0
        val courseLessons = lessons.value.filter { it.courseId == courseId && it.status == "published" }
        if (courseLessons.isEmpty()) return 0 to 0
        val completedCount = courseLessons.count { lesson ->
            progressList.value.any { it.studentId == studentId && it.courseId == courseId && it.lessonId == lesson.id && it.isCompleted }
        }
        return completedCount to courseLessons.size
    }

    fun isLessonCompleted(courseId: String, lessonId: String, studentId: String? = currentUser.value?.id): Boolean {
        if (studentId == null) return false
        return progressList.value.any { 
            it.studentId == studentId && it.courseId == courseId && it.lessonId == lessonId && it.isCompleted 
        }
    }

    fun toggleLessonCompleted(courseId: String, lessonId: String) {
        val studentId = currentUser.value?.id ?: return
        repository.toggleLessonCompletion(studentId, courseId, lessonId)
    }

    fun nextLesson(courseId: String, currentLessonId: String) {
        val courseLessons = lessons.value.filter { it.courseId == courseId && it.status == "published" }.sortedBy { it.displayOrder }
        val currentIndex = courseLessons.indexOfFirst { it.id == currentLessonId }
        if (currentIndex != -1 && currentIndex < courseLessons.size - 1) {
            _selectedLessonId.value = courseLessons[currentIndex + 1].id
        }
    }

    fun previousLesson(courseId: String, currentLessonId: String) {
        val courseLessons = lessons.value.filter { it.courseId == courseId && it.status == "published" }.sortedBy { it.displayOrder }
        val currentIndex = courseLessons.indexOfFirst { it.id == currentLessonId }
        if (currentIndex > 0) {
            _selectedLessonId.value = courseLessons[currentIndex - 1].id
        }
    }
}
