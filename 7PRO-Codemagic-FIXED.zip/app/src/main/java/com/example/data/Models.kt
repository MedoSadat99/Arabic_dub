package com.example.data

enum class UserRole {
    STUDENT, ADMIN
}

enum class UserStatus {
    ACTIVE, PENDING, DISABLED
}

data class Student(
    val id: String,
    val name: String,
    val email: String,
    val passwordHash: String,
    val status: UserStatus = UserStatus.ACTIVE,
    val role: UserRole = UserRole.STUDENT,
    val createdAt: Long = System.currentTimeMillis()
)

data class Course(
    val id: String,
    val title: String,
    val description: String,
    val imageUrl: String,
    val isOpenToAll: Boolean = false, // true: فتح الكورس للجميع (متاح لكافة الطلاب), false: قفل الكورس (يتطلب تفعيل فردي من الإدارة)
    val isPublished: Boolean = true, // Published vs Draft
    val isHidden: Boolean = false, // Visible vs Hidden
    val displayOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class Lesson(
    val id: String,
    val courseId: String,
    val title: String,
    val duration: String, // e.g. "08:20"
    val videoUrl: String,
    val displayOrder: Int = 0,
    val status: String = "published" // published, draft, disabled
)

data class CourseAssignment(
    val id: String,
    val studentId: String,
    val courseId: String,
    val assignedAt: Long = System.currentTimeMillis()
)

data class LessonProgress(
    val studentId: String,
    val courseId: String,
    val lessonId: String,
    val isCompleted: Boolean = false,
    val progressSeconds: Long = 0,
    val lastWatchedAt: Long = System.currentTimeMillis()
)

data class AppearanceSettings(
    val logoUrl: String = "ic_7pro_logo",
    val heroHeadline: String = "دورات 7PRO لتعلّم الإنجليزية",
    val welcomeText: String = "طوّر لغتك الإنجليزية مع نخبة من الدورات الاحترافية"
)

data class AppSettings(
    val registrationEnabled: Boolean = true,
    val maintenanceMode: Boolean = false,
    val maintenanceMessage: String = "المنصة قيد الصيانة الدورية لتحسين التجربة، سنعود قريباً!",
    val appVersion: String = "1.0.0",
    val minSupportedVersion: String = "1.0.0",
    val forceUpdate: Boolean = false,
    val updateMessage: String = "يوجد تحديث جديد متاح لمنصة 7PRO بميزات وتحسينات جديدة.",
    val updateUrl: String = "https://7pro.com/download",
    val backendStatus: String = "متصل وعملي (MongoDB + FastAPI)"
)

data class PasswordResetToken(
    val code: String,
    val email: String,
    val expiresAt: Long,
    val isUsed: Boolean = false
)

data class AuditLog(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val action: String,
    val details: String,
    val adminEmail: String,
    val ipAddress: String = "127.0.0.1"
)

