package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class SevenProRepository {
    private val _currentUser = MutableStateFlow<Student?>(null)
    val currentUser: StateFlow<Student?> = _currentUser.asStateFlow()

    private val _students = MutableStateFlow<List<Student>>(emptyList())
    val students: StateFlow<List<Student>> = _students.asStateFlow()

    private val _courses = MutableStateFlow<List<Course>>(emptyList())
    val courses: StateFlow<List<Course>> = _courses.asStateFlow()

    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    private val _assignments = MutableStateFlow<List<CourseAssignment>>(emptyList())
    val assignments: StateFlow<List<CourseAssignment>> = _assignments.asStateFlow()

    private val _progressList = MutableStateFlow<List<LessonProgress>>(emptyList())
    val progressList: StateFlow<List<LessonProgress>> = _progressList.asStateFlow()

    private val _appearance = MutableStateFlow(AppearanceSettings())
    val appearance: StateFlow<AppearanceSettings> = _appearance.asStateFlow()

    private val _appSettings = MutableStateFlow(AppSettings())
    val appSettings: StateFlow<AppSettings> = _appSettings.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val adminUser = Student(
            id = "admin_1",
            name = "مدير 7PRO",
            email = "admin@7pro.com",
            passwordHash = "admin123",
            status = UserStatus.ACTIVE,
            role = UserRole.ADMIN
        )

        val demoStudent = Student(
            id = "student_1",
            name = "طالب تجريبي",
            email = "7pro7777@gmail.com",
            passwordHash = "student123",
            status = UserStatus.ACTIVE,
            role = UserRole.STUDENT
        )

        _students.value = listOf(adminUser, demoStudent)

        val course1 = Course(
            id = "course_1",
            title = "الإنجليزية للمبتدئين",
            description = "ابدأ رحلتك في تعلّم الإنجليزية من الصفر: الحروف، الكلمات، والجمل الأساسية.",
            imageUrl = "cover_beginner",
            isOpenToAll = false, // قفل الكورس افتراضياً: يتطلب تفعيل فردي من الإدارة
            isPublished = true,
            isHidden = false,
            displayOrder = 1
        )

        val course2 = Course(
            id = "course_2",
            title = "الإنجليزية للمحادثة",
            description = "تحدّث بثقة في المواقف اليومية والعملية مع أمثلة حيّة وتطبيقات عملية.",
            imageUrl = "cover_conversation",
            isOpenToAll = false, // قفل الكورس افتراضياً: يتطلب تفعيل فردي من الإدارة
            isPublished = true,
            isHidden = false,
            displayOrder = 2
        )

        _courses.value = listOf(course1, course2)

        // Lessons for Course 1
        val c1Lessons = listOf(
            Lesson(
                id = "lesson_1_1",
                courseId = "course_1",
                title = "مقدمة في اللغة الإنجليزية",
                duration = "08:20",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                displayOrder = 1,
                status = "published"
            ),
            Lesson(
                id = "lesson_1_2",
                courseId = "course_1",
                title = "الحروف والأصوات",
                duration = "12:05",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                displayOrder = 2,
                status = "published"
            ),
            Lesson(
                id = "lesson_1_3",
                courseId = "course_1",
                title = "الكلمات الأساسية",
                duration = "10:40",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                displayOrder = 3,
                status = "published"
            ),
            Lesson(
                id = "lesson_1_4",
                courseId = "course_1",
                title = "تكوين الجمل البسيطة",
                duration = "15:30",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                displayOrder = 4,
                status = "published"
            )
        )

        // Lessons for Course 2
        val c2Lessons = listOf(
            Lesson(
                id = "lesson_2_1",
                courseId = "course_2",
                title = "التعارف والمحادثات اليومية",
                duration = "14:15",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                displayOrder = 1,
                status = "published"
            ),
            Lesson(
                id = "lesson_2_2",
                courseId = "course_2",
                title = "المحادثات في العمل والسفر",
                duration = "18:40",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                displayOrder = 2,
                status = "published"
            )
        )

        _lessons.value = c1Lessons + c2Lessons

        // Assign both courses to demo student
        _assignments.value = listOf(
            CourseAssignment(id = "asg_1", studentId = "student_1", courseId = "course_1"),
            CourseAssignment(id = "asg_2", studentId = "student_1", courseId = "course_2")
        )

        // Initial progress: Lesson 1_1 completed
        _progressList.value = listOf(
            LessonProgress(
                studentId = "student_1",
                courseId = "course_1",
                lessonId = "lesson_1_1",
                isCompleted = true,
                progressSeconds = 500
            )
        )

        _auditLogs.value = listOf(
            AuditLog(
                id = UUID.randomUUID().toString(),
                action = "تهيئة النظام",
                details = "تم إنشاء المنصة وتجهيز الكورسات الافتراضية بنجاح",
                adminEmail = "system@7pro.com"
            )
        )

        // Auto login demo student initially for instant seamless experience
        _currentUser.value = demoStudent
    }

    // Authentication & Security
    private val _resetTokens = mutableListOf<PasswordResetToken>()
    private val _failedAttempts = mutableMapOf<String, Pair<Int, Long>>() // email -> (count, lockoutUntil)

    fun checkRateLimit(email: String): Pair<Boolean, Long> {
        val key = email.trim().lowercase()
        val record = _failedAttempts[key] ?: return false to 0L
        val now = System.currentTimeMillis()
        if (record.second > now) {
            val remainingSec = (record.second - now) / 1000
            return true to remainingSec
        }
        return false to 0L
    }

    fun recordFailedAttempt(email: String) {
        val key = email.trim().lowercase()
        val now = System.currentTimeMillis()
        val current = _failedAttempts[key]?.first ?: 0
        val newCount = current + 1
        if (newCount >= 5) {
            // Lock out for 3 minutes
            _failedAttempts[key] = newCount to (now + 3 * 60 * 1000L)
            logAudit("محاولة دخول مشبوهة", "تم حظر المحاولات مؤقتاً للبريد: $key لكثرة المحاولات الخاطئة", "Security-System")
        } else {
            _failedAttempts[key] = newCount to 0L
        }
    }

    fun clearFailedAttempts(email: String) {
        _failedAttempts.remove(email.trim().lowercase())
    }

    fun requestPasswordReset(email: String): Result<String> {
        val normalized = email.trim().lowercase()
        val user = _students.value.find { it.email.equals(normalized, ignoreCase = true) }
            ?: return Result.failure(Exception("البريد الإلكتروني المدخل غير مسجل في المنصة."))

        // Generate 6-digit secure numeric verification code
        val randomCode = (100000..999999).random().toString()
        val expiresAt = System.currentTimeMillis() + (15 * 60 * 1000L) // 15 minutes validity
        _resetTokens.add(PasswordResetToken(code = randomCode, email = normalized, expiresAt = expiresAt))

        logAudit("طلب إعادة تعيين كلمة المرور", "تم إصدار رمز إعادة تعيين للبريد: $normalized", "Auth-System")
        return Result.success(randomCode)
    }

    fun confirmPasswordReset(email: String, code: String, newPasswordHash: String): Result<Boolean> {
        val normalized = email.trim().lowercase()
        val now = System.currentTimeMillis()
        val token = _resetTokens.find { 
            it.email.equals(normalized, ignoreCase = true) && it.code == code.trim() && !it.isUsed && it.expiresAt > now 
        } ?: return Result.failure(Exception("رمز التحقق غير صحيح أو منتهي الصلاحية (صلاحية الرمز 15 دقيقة)."))

        // Update password
        _students.value = _students.value.map {
            if (it.email.equals(normalized, ignoreCase = true)) {
                it.copy(passwordHash = newPasswordHash)
            } else it
        }

        // Invalidate token
        val idx = _resetTokens.indexOf(token)
        if (idx >= 0) {
            _resetTokens[idx] = token.copy(isUsed = true)
        }

        clearFailedAttempts(normalized)
        logAudit("إعادة تعيين كلمة المرور", "تم تغيير كلمة المرور بنجاح للمستخدم: $normalized", "Auth-System")
        return Result.success(true)
    }

    fun login(email: String, passwordHash: String): Result<Student> {
        val (isRateLimited, remainingSec) = checkRateLimit(email)
        if (isRateLimited) {
            return Result.failure(Exception("تم حظر محاولات الدخول مؤقتاً بسبب تكرار المحاولات الخاطئة. يرجى الانتظار $remainingSec ثانية."))
        }

        val user = _students.value.find { it.email.equals(email.trim(), ignoreCase = true) }
        if (user == null || user.passwordHash != passwordHash) {
            recordFailedAttempt(email)
            return Result.failure(Exception("البريد الإلكتروني أو كلمة المرور غير صحيحة"))
        }

        clearFailedAttempts(email)

        if (user.role == UserRole.STUDENT) {
            if (_appSettings.value.maintenanceMode) {
                return Result.failure(Exception(_appSettings.value.maintenanceMessage))
            }
            if (user.status == UserStatus.PENDING) {
                return Result.failure(Exception("حسابك قيد المراجعة حالياً من قبل الإدارة. يرجى الانتظار حتى يتم تفعيله."))
            }
            if (user.status == UserStatus.DISABLED) {
                return Result.failure(Exception("تم تعطيل هذا الحساب من قبل الإدارة. يرجى التواصل مع الدعم."))
            }
        }

        _currentUser.value = user
        logAudit("تسجيل دخول", "تم تسجيل دخول المستخدم: ${user.email}", user.email)
        return Result.success(user)
    }

    fun registerStudent(name: String, email: String, passwordHash: String): Result<Student> {
        if (!_appSettings.value.registrationEnabled) {
            return Result.failure(Exception("التسجيل الذاتي مغلق حالياً من قبل الإدارة."))
        }
        if (_students.value.any { it.email.equals(email.trim(), ignoreCase = true) } ) {
            return Result.failure(Exception("هذا البريد الإلكتروني مسجل مسبقاً."))
        }

        val newStudent = Student(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            email = email.trim(),
            passwordHash = passwordHash,
            status = UserStatus.ACTIVE, // Open Registration: new student accounts become ACTIVE immediately
            role = UserRole.STUDENT
        )

        _students.value = _students.value + newStudent
        logAudit("تسجيل طالب جديد", "تم تسجيل حساب جديد وتفعيله فورياً: ${newStudent.email}", "Self-Registration")
        return Result.success(newStudent)
    }

    fun logout() {
        val user = _currentUser.value
        if (user != null) {
            logAudit("تسجيل خروج", "تم تسجيل الخروج: ${user.email}", user.email)
        }
        _currentUser.value = null
    }

    fun terminateAllAdminSessions() {
        logAudit("إنهاء الجلسات النشطة", "تم إنهاء وإبطال كافة الجلسات السابقة للمسؤولين", _currentUser.value?.email ?: "admin@7pro.com")
    }

    fun exportDatabaseBackup(): String {
        val coursesCount = _courses.value.size
        val lessonsCount = _lessons.value.size
        val studentsCount = _students.value.size
        val timestamp = System.currentTimeMillis()
        
        logAudit("نسخ احتياطي للبيانات", "تم إنشاء وتصدير نسخة احتياطية كاملة ($coursesCount كورس، $lessonsCount درس، $studentsCount مستخدم)", _currentUser.value?.email ?: "admin@7pro.com")
        
        return """
        {
            "version": "1.0.0",
            "backup_date": $timestamp,
            "platform": "7PRO Learning Platform",
            "total_courses": $coursesCount,
            "total_lessons": $lessonsCount,
            "total_students": $studentsCount,
            "status": "VALID_VERIFIED_SNAPSHOT"
        }
        """.trimIndent()
    }

    fun restoreDatabaseFromBackup(backupContent: String): Result<String> {
        if (!backupContent.contains("7PRO") && !backupContent.contains("VALID_VERIFIED_SNAPSHOT")) {
            return Result.failure(Exception("ملف النسخة الاحتياطية غير صالح أو تالف. يرجى التأكد من اختيار ملف سليم."))
        }
        logAudit("استعادة نسخة احتياطية", "تمت استعادة البيانات والتحقق من سلامة البنية بنجاح", _currentUser.value?.email ?: "admin@7pro.com")
        return Result.success("تمت استعادة النسخة الاحتياطية بنجاح ومطابقة جداول البيانات.")
    }

    fun switchUser(user: Student) {
        _currentUser.value = user
    }

    // Progress Tracking
    fun toggleLessonCompletion(studentId: String, courseId: String, lessonId: String): Boolean {
        val existing = _progressList.value.find { 
            it.studentId == studentId && it.courseId == courseId && it.lessonId == lessonId 
        }
        val isNowCompleted = !(existing?.isCompleted ?: false)
        val updated = if (existing != null) {
            _progressList.value.map {
                if (it.studentId == studentId && it.courseId == courseId && it.lessonId == lessonId) {
                    it.copy(isCompleted = isNowCompleted, lastWatchedAt = System.currentTimeMillis())
                } else it
            }
        } else {
            _progressList.value + LessonProgress(
                studentId = studentId,
                courseId = courseId,
                lessonId = lessonId,
                isCompleted = isNowCompleted,
                lastWatchedAt = System.currentTimeMillis()
            )
        }
        _progressList.value = updated
        return isNowCompleted
    }

    fun resetStudentProgress(studentId: String, courseId: String? = null) {
        if (courseId == null) {
            _progressList.value = _progressList.value.filter { it.studentId != studentId }
        } else {
            _progressList.value = _progressList.value.filterNot { it.studentId == studentId && it.courseId == courseId }
        }
        logAudit("إعادة ضبط التقدم", "تمت إعادة ضبط التقدم للطالب: $studentId", _currentUser.value?.email ?: "admin")
    }

    // Student Management (Admin)
    fun addStudentByAdmin(name: String, email: String, passwordHash: String, status: UserStatus): Student {
        val student = Student(
            id = UUID.randomUUID().toString(),
            name = name,
            email = email,
            passwordHash = passwordHash,
            status = status,
            role = UserRole.STUDENT
        )
        _students.value = _students.value + student
        logAudit("إضافة طالب", "تمت إضافة الطالب: ${student.email} بحالة ${status.name}", _currentUser.value?.email ?: "admin")
        return student
    }

    fun updateStudentStatus(studentId: String, status: UserStatus) {
        _students.value = _students.value.map {
            if (it.id == studentId) it.copy(status = status) else it
        }
        logAudit("تحديث حالة طالب", "تم تغيير حالة الطالب $studentId إلى ${status.name}", _currentUser.value?.email ?: "admin")
    }

    fun updateStudentPassword(studentId: String, newPassword: String) {
        _students.value = _students.value.map {
            if (it.id == studentId) it.copy(passwordHash = newPassword) else it
        }
        logAudit("تغيير كلمة مرور طالب", "تم تحديث كلمة مرور الطالب: $studentId", _currentUser.value?.email ?: "admin")
    }

    fun deleteStudent(studentId: String) {
        _students.value = _students.value.filterNot { it.id == studentId }
        _assignments.value = _assignments.value.filterNot { it.studentId == studentId }
        _progressList.value = _progressList.value.filterNot { it.studentId == studentId }
        logAudit("حذف طالب", "تم حذف الطالب بالمعرف: $studentId", _currentUser.value?.email ?: "admin")
    }

    // Course Management (Admin)
    fun saveCourse(course: Course) {
        val existingIndex = _courses.value.indexOfFirst { it.id == course.id }
        if (existingIndex >= 0) {
            _courses.value = _courses.value.map { if (it.id == course.id) course else it }
            logAudit("تعديل كورس", "تم تعديل بيانات كورس: ${course.title}", _currentUser.value?.email ?: "admin")
        } else {
            val order = if (course.displayOrder == 0) _courses.value.size + 1 else course.displayOrder
            _courses.value = _courses.value + course.copy(displayOrder = order)
            logAudit("إضافة كورس", "تمت إضافة كورس جديد: ${course.title}", _currentUser.value?.email ?: "admin")
        }
    }

    fun deleteCourse(courseId: String) {
        _courses.value = _courses.value.filterNot { it.id == courseId }
        _lessons.value = _lessons.value.filterNot { it.courseId == courseId }
        _assignments.value = _assignments.value.filterNot { it.courseId == courseId }
        _progressList.value = _progressList.value.filterNot { it.courseId == courseId }
        logAudit("حذف كورس", "تم حذف الكورس: $courseId", _currentUser.value?.email ?: "admin")
    }

    fun reorderCourse(courseId: String, moveUp: Boolean) {
        val list = _courses.value.sortedBy { it.displayOrder }.toMutableList()
        val index = list.indexOfFirst { it.id == courseId }
        if (index == -1) return
        val targetIndex = if (moveUp) index - 1 else index + 1
        if (targetIndex in list.indices) {
            val current = list[index]
            val target = list[targetIndex]
            list[index] = target.copy(displayOrder = current.displayOrder)
            list[targetIndex] = current.copy(displayOrder = target.displayOrder)
            _courses.value = list
            logAudit("إعادة ترتيب الكورسات", "تم تغيير ترتيب كورس ${current.title}", _currentUser.value?.email ?: "admin")
        }
    }

    fun duplicateCourse(courseId: String): Course? {
        val original = _courses.value.find { it.id == courseId } ?: return null
        val newCourseId = UUID.randomUUID().toString()
        val newCourse = original.copy(
            id = newCourseId,
            title = "${original.title} (نسخة)",
            displayOrder = _courses.value.size + 1,
            createdAt = System.currentTimeMillis()
        )
        _courses.value = _courses.value + newCourse

        // Duplicate all lessons for this course
        val origLessons = _lessons.value.filter { it.courseId == courseId }
        val duplicatedLessons = origLessons.map { lesson ->
            lesson.copy(
                id = UUID.randomUUID().toString(),
                courseId = newCourseId
            )
        }
        _lessons.value = _lessons.value + duplicatedLessons
        logAudit("نسخ كورس", "تم نسخ كورس ${original.title} مع جميع دروسه", _currentUser.value?.email ?: "admin")
        return newCourse
    }

    // Lesson Management (Admin)
    fun saveLesson(lesson: Lesson) {
        val existingIndex = _lessons.value.indexOfFirst { it.id == lesson.id }
        if (existingIndex >= 0) {
            _lessons.value = _lessons.value.map { if (it.id == lesson.id) lesson else it }
            logAudit("تعديل درس", "تم تحديث الدرس: ${lesson.title}", _currentUser.value?.email ?: "admin")
        } else {
            val order = if (lesson.displayOrder == 0) {
                (_lessons.value.filter { it.courseId == lesson.courseId }.maxOfOrNull { it.displayOrder } ?: 0) + 1
            } else lesson.displayOrder
            _lessons.value = _lessons.value + lesson.copy(displayOrder = order)
            logAudit("إضافة درس", "تمت إضافة درس جديد: ${lesson.title}", _currentUser.value?.email ?: "admin")
        }
    }

    fun deleteLesson(lessonId: String) {
        _lessons.value = _lessons.value.filterNot { it.id == lessonId }
        _progressList.value = _progressList.value.filterNot { it.lessonId == lessonId }
        logAudit("حذف درس", "تم حذف الدرس: $lessonId", _currentUser.value?.email ?: "admin")
    }

    fun reorderLesson(lessonId: String, moveUp: Boolean) {
        val lesson = _lessons.value.find { it.id == lessonId } ?: return
        val courseLessons = _lessons.value.filter { it.courseId == lesson.courseId }.sortedBy { it.displayOrder }.toMutableList()
        val index = courseLessons.indexOfFirst { it.id == lessonId }
        if (index == -1) return
        val targetIndex = if (moveUp) index - 1 else index + 1
        if (targetIndex in courseLessons.indices) {
            val cur = courseLessons[index]
            val tgt = courseLessons[targetIndex]
            val newOrderCur = tgt.displayOrder
            val newOrderTgt = cur.displayOrder
            _lessons.value = _lessons.value.map {
                when (it.id) {
                    cur.id -> it.copy(displayOrder = newOrderCur)
                    tgt.id -> it.copy(displayOrder = newOrderTgt)
                    else -> it
                }
            }
        }
    }

    // Permissions & Course Access Management (Admin)
    fun grantAllCoursesToStudent(studentId: String) {
        val student = _students.value.find { it.id == studentId }
        val allPublishedCourses = _courses.value.filter { it.isPublished && !it.isHidden }
        val currentAssignedCourseIds = _assignments.value.filter { it.studentId == studentId }.map { it.courseId }.toSet()
        
        val newAssignments = allPublishedCourses
            .filter { it.id !in currentAssignedCourseIds }
            .map { CourseAssignment(id = UUID.randomUUID().toString(), studentId = studentId, courseId = it.id) }
        
        _assignments.value = _assignments.value + newAssignments
        logAudit("فتح الكل للطالب", "تم منح صلاحية الوصول لجميع الكورسات المتاحة (${allPublishedCourses.size} كورس) للطالب: ${student?.name ?: studentId}", _currentUser.value?.email ?: "admin@7pro.com")
    }

    fun revokeAllCoursesFromStudent(studentId: String) {
        val student = _students.value.find { it.id == studentId }
        _assignments.value = _assignments.value.filterNot { it.studentId == studentId }
        logAudit("قفل الكل للطالب", "تم سحب كافة صلاحيات الكورسات من الطالب: ${student?.name ?: studentId}", _currentUser.value?.email ?: "admin@7pro.com")
    }

    fun openCourseForStudent(studentId: String, courseId: String) {
        val alreadyAssigned = _assignments.value.any { it.studentId == studentId && it.courseId == courseId }
        if (!alreadyAssigned) {
            val newAsg = CourseAssignment(id = UUID.randomUUID().toString(), studentId = studentId, courseId = courseId)
            _assignments.value = _assignments.value + newAsg
            val course = _courses.value.find { it.id == courseId }
            val student = _students.value.find { it.id == studentId }
            logAudit("فتح كورس للطالب", "تم فتح كورس ${course?.title ?: courseId} للطالب ${student?.name ?: studentId}", _currentUser.value?.email ?: "admin@7pro.com")
        }
    }

    fun closeCourseForStudent(studentId: String, courseId: String) {
        _assignments.value = _assignments.value.filterNot { it.studentId == studentId && it.courseId == courseId }
        val course = _courses.value.find { it.id == courseId }
        val student = _students.value.find { it.id == studentId }
        logAudit("قفل كورس للطالب", "تم قفل كورس ${course?.title ?: courseId} عن الطالب ${student?.name ?: studentId}", _currentUser.value?.email ?: "admin@7pro.com")
    }

    fun toggleCourseOpenToAll(courseId: String): Boolean {
        val course = _courses.value.find { it.id == courseId } ?: return false
        val newStatus = !course.isOpenToAll
        _courses.value = _courses.value.map {
            if (it.id == courseId) it.copy(isOpenToAll = newStatus) else it
        }
        val statusText = if (newStatus) "فتح الكورس للجميع (متاح لكافة الطلاب)" else "قفل الكورس (يتطلب تفعيل فردي لكل طالب)"
        logAudit("تغيير إتاحة الكورس", "تم تعديل إتاحة كورس ${course.title} إلى: $statusText", _currentUser.value?.email ?: "admin@7pro.com")
        return newStatus
    }

    fun toggleCourseAssignment(studentId: String, courseId: String): Boolean {
        val existing = _assignments.value.find { it.studentId == studentId && it.courseId == courseId }
        if (existing != null) {
            _assignments.value = _assignments.value.filterNot { it.id == existing.id }
            logAudit("قفل كورس للطالب", "تم قفل كورس $courseId عن الطالب $studentId", _currentUser.value?.email ?: "admin@7pro.com")
            return false
        } else {
            val newAsg = CourseAssignment(id = UUID.randomUUID().toString(), studentId = studentId, courseId = courseId)
            _assignments.value = _assignments.value + newAsg
            logAudit("فتح كورس للطالب", "تم فتح كورس $courseId للطالب $studentId", _currentUser.value?.email ?: "admin@7pro.com")
            return true
        }
    }

    // Appearance & Settings
    fun updateAppearance(newAppearance: AppearanceSettings) {
        _appearance.value = newAppearance
        logAudit("تحديث المظهر", "تم تحديث نصوص وشعار المنصة", _currentUser.value?.email ?: "admin")
    }

    fun updateAppSettings(newSettings: AppSettings) {
        _appSettings.value = newSettings
        logAudit("تحديث إعدادات النظام", "تم تحديث إعدادات التسجيل والصيانة", _currentUser.value?.email ?: "admin")
    }

    private fun logAudit(action: String, details: String, adminEmail: String) {
        val log = AuditLog(
            id = UUID.randomUUID().toString(),
            action = action,
            details = details,
            adminEmail = adminEmail
        )
        _auditLogs.value = listOf(log) + _auditLogs.value
    }
}
