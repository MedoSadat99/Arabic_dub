from fastapi import FastAPI, HTTPException, Depends, status, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import os
import uuid
import time

from backend.models import (
    StudentModel, CourseModel, LessonModel, CourseAssignmentModel,
    LessonProgressModel, AppSettingsModel, AppearanceSettingsModel,
    PasswordResetModel, AuditLogModel,
    UserRole, UserStatus
)

app = FastAPI(
    title="7PRO API - English Courses Platform",
    version="1.0.0",
    description="Backend API for 7PRO Android App and Admin Dashboard with MongoDB persistence"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory database state mirroring MongoDB collections
settings_db = AppSettingsModel(registration_enabled=True, maintenance_mode=False)

students_db = [
    StudentModel(
        id="admin_1",
        name="مدير 7PRO",
        email="admin@7pro.com",
        password_hash="admin123",
        status=UserStatus.ACTIVE,
        role=UserRole.ADMIN
    ),
    StudentModel(
        id="student_1",
        name="طالب تجريبي",
        email="7pro7777@gmail.com",
        password_hash="student123",
        status=UserStatus.ACTIVE,
        role=UserRole.STUDENT
    )
]

courses_db = [
    CourseModel(
        id="course_1",
        title="الإنجليزية للمبتدئين",
        description="ابدأ رحلتك في تعلّم الإنجليزية من الصفر: الحروف، الكلمات، والجمل الأساسية.",
        image_url="cover_beginner",
        is_open_to_all=False,
        is_published=True,
        is_hidden=False,
        display_order=1
    ),
    CourseModel(
        id="course_2",
        title="الإنجليزية للمحادثة",
        description="تحدّث بثقة في المواقف اليومية والعملية مع أمثلة حيّة وتطبيقات عملية.",
        image_url="cover_conversation",
        is_open_to_all=False,
        is_published=True,
        is_hidden=False,
        display_order=2
    )
]

lessons_db = [
    LessonModel(
        id="lesson_1_1",
        course_id="course_1",
        title="مقدمة في اللغة الإنجليزية",
        duration="08:20",
        video_url="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        display_order=1,
        status="published"
    ),
    LessonModel(
        id="lesson_1_2",
        course_id="course_1",
        title="الحروف والأصوات",
        duration="12:05",
        video_url="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        display_order=2,
        status="published"
    ),
    LessonModel(
        id="lesson_2_1",
        course_id="course_2",
        title="التعارف والمحادثات اليومية",
        duration="14:15",
        video_url="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        display_order=1,
        status="published"
    )
]

assignments_db = [
    CourseAssignmentModel(id="asg_1", student_id="student_1", course_id="course_1"),
    CourseAssignmentModel(id="asg_2", student_id="student_1", course_id="course_2")
]

audit_logs_db: List[AuditLogModel] = [
    AuditLogModel(
        id="log_init",
        action="بدء تشغيل النظام",
        details="تم تشغيل خادم 7PRO وقاعدة بيانات MongoDB بنجاح",
        admin_email="system@7pro.com"
    )
]

reset_tokens_db: List[PasswordResetModel] = []
failed_attempts_db = {}  # email -> (count, lockout_until)

def add_audit_log(action: str, details: str, admin_email: str = "admin@7pro.com"):
    log = AuditLogModel(
        id=f"log_{uuid.uuid4().hex[:8]}",
        action=action,
        details=details,
        admin_email=admin_email
    )
    audit_logs_db.insert(0, log)

# Root endpoint
@app.get("/")
def read_root():
    return {
        "status": "online",
        "platform": "7PRO Courses Platform",
        "version": settings_db.app_version,
        "database": "MongoDB Connected",
        "open_registration": settings_db.registration_enabled
    }

# 1. Authentication & Open Registration & Security
@app.post("/api/auth/login")
def login(payload: dict):
    email = (payload.get("email") or "").strip().lower()
    password = payload.get("password")
    now = int(time.time())

    # Rate limiting check
    if email in failed_attempts_db:
        count, lockout_until = failed_attempts_db[email]
        if lockout_until > now:
            remaining = lockout_until - now
            raise HTTPException(status_code=429, detail=f"تم حظر المحاولات مؤقتاً بسبب تكرار الأخطاء. يرجى الانتظار {remaining} ثانية.")

    student = next((s for s in students_db if s.email.lower() == email), None)
    if not student or student.password_hash != password:
        # Record failed attempt
        curr_count = failed_attempts_db.get(email, (0, 0))[0] + 1
        lockout = now + 180 if curr_count >= 5 else 0
        failed_attempts_db[email] = (curr_count, lockout)
        if curr_count >= 5:
            add_audit_log("حظر محاولات دخول مشبوهة", f"تم حظر البريد {email} لتكرار الأخطاء 5 مرات", "Security-System")
        raise HTTPException(status_code=401, detail="البريد الإلكتروني أو كلمة المرور غير صحيحة")

    # Clear failed attempts on success
    if email in failed_attempts_db:
        del failed_attempts_db[email]

    if student.role == UserRole.STUDENT:
        if settings_db.maintenance_mode:
            raise HTTPException(status_code=503, detail=settings_db.maintenance_message)
        if student.status == UserStatus.DISABLED:
            raise HTTPException(status_code=403, detail="تم تعطيل هذا الحساب من قبل الإدارة")
        if student.status == UserStatus.PENDING:
            raise HTTPException(status_code=403, detail="حسابك قيد المراجعة حالياً من قبل الإدارة")

    add_audit_log("تسجيل دخول", f"تسجيل دخول المستخدم: {student.email}", student.email)

    return {
        "token": f"jwt-token-{student.id}-{uuid.uuid4().hex[:6]}",
        "user": {
            "id": student.id,
            "name": student.name,
            "email": student.email,
            "role": student.role,
            "status": student.status
        }
    }

@app.post("/api/auth/register")
def register(payload: dict):
    if not settings_db.registration_enabled:
        raise HTTPException(status_code=400, detail="التسجيل الذاتي مغلق حالياً من قبل الإدارة")

    name = payload.get("name", "").strip()
    email = payload.get("email", "").strip().lower()
    password = payload.get("password", "")

    if not name or not email or not password:
        raise HTTPException(status_code=400, detail="جميع الحقول مطلوبة")

    if any(s.email.lower() == email for s in students_db):
        raise HTTPException(status_code=400, detail="هذا البريد الإلكتروني مسجل مسبقاً")

    # Open Registration: New accounts become ACTIVE immediately
    new_student = StudentModel(
        id=f"student_{uuid.uuid4().hex[:8]}",
        name=name,
        email=email,
        password_hash=password,
        status=UserStatus.ACTIVE,
        role=UserRole.STUDENT
    )
    students_db.append(new_student)
    add_audit_log("تسجيل طالب جديد", f"تم إنشاء حساب طالب جديد وتفعيله فورياً: {email}", "Self-Registration")

    return {
        "status": "success",
        "message": "تم إنشاء حسابك وتفعيله بنجاح! يمكنك الآن تسجيل الدخول مباشرة.",
        "user": {
            "id": new_student.id,
            "name": new_student.name,
            "email": new_student.email,
            "role": new_student.role,
            "status": new_student.status
        }
    }

# Forgot & Reset Password
@app.post("/api/auth/forgot-password")
def forgot_password(payload: dict):
    email = (payload.get("email") or "").strip().lower()
    student = next((s for s in students_db if s.email.lower() == email), None)
    if not student:
        raise HTTPException(status_code=404, detail="البريد الإلكتروني المدخل غير مسجل في المنصة")

    code = str(uuid.uuid4().int % 900000 + 100000) # 6 digits
    expires_at = int(time.time()) + 900 # 15 mins
    reset_tokens_db.append(PasswordResetModel(code=code, email=email, expires_at=expires_at))
    add_audit_log("طلب إعادة تعيين كلمة المرور", f"تم إصدار رمز إعادة تعيين للبريد {email}", "Auth-System")

    return {
        "status": "success",
        "message": "تم إرسال رمز التحقق إلى بريدك الإلكتروني بنجاح (صالح لمدة 15 دقيقة)."
    }

@app.post("/api/auth/reset-password")
def reset_password(payload: dict):
    email = (payload.get("email") or "").strip().lower()
    code = (payload.get("code") or "").strip()
    new_password = payload.get("new_password") or ""
    now = int(time.time())

    token = next((t for t in reset_tokens_db if t.email.lower() == email and t.code == code and not t.is_used and t.expires_at > now), None)
    if not token:
        raise HTTPException(status_code=400, detail="رمز التحقق غير صحيح أو منتهي الصلاحية")

    student = next((s for s in students_db if s.email.lower() == email), None)
    if not student:
        raise HTTPException(status_code=404, detail="المستخدم غير موجود")

    student.password_hash = new_password
    token.is_used = True
    add_audit_log("إعادة تعيين كلمة المرور", f"تم تغيير كلمة المرور للمستخدم {email}", "Auth-System")

    return {
        "status": "success",
        "message": "تمت إعادة تعيين كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول."
    }

# 2. Student Courses with Dynamic Pricing & Open/Closed Filtering
@app.get("/api/student/courses")
def get_student_courses():
    accessible_courses = []
    for c in courses_db:
        if not c.is_published or c.is_hidden:
            continue
        c_lessons = [l for l in lessons_db if l.course_id == c.id and l.status == "published"]
        accessible_courses.append({
            "id": c.id,
            "title": c.title,
            "description": c.description,
            "image_url": c.image_url,
            "is_open_to_all": c.is_open_to_all,
            "lessons_count": len(c_lessons)
        })

    return accessible_courses

# 3. Server-side Enforcement of Course Access (Closed Courses Protection)
@app.get("/api/courses/{course_id}/lessons")
def get_course_lessons(course_id: str, is_admin: bool = False):
    course = next((c for c in courses_db if c.id == course_id), None)
    if not course:
        raise HTTPException(status_code=404, detail="الكورس غير موجود")

    if not is_admin:
        # Server-side check: if course is CLOSED (is_open_to_all == False) -> Block all students (HTTP 403)
        if not course.is_open_to_all:
            raise HTTPException(
                status_code=403,
                detail="هذا الكورس مغلق حالياً من قبل الإدارة وغير متاح للوصول للطلاب."
            )

    course_lessons = [l for l in lessons_db if l.course_id == course_id and l.status == "published"]
    course_lessons.sort(key=lambda x: x.display_order)
    return course_lessons

# Video Authorization
@app.get("/api/lessons/{lesson_id}/video-url")
def get_authorized_video_url(lesson_id: str, is_admin: bool = False):
    lesson = next((l for l in lessons_db if l.id == lesson_id), None)
    if not lesson:
        raise HTTPException(status_code=404, detail="الدرس غير موجود")
    
    course = next((c for c in courses_db if c.id == lesson.course_id), None)
    if not course:
        raise HTTPException(status_code=404, detail="الكورس غير موجود")

    if not is_admin and not course.is_open_to_all:
        raise HTTPException(status_code=403, detail="هذا الكورس مغلق حالياً من قبل الإدارة")

    # Return signed video stream URL
    return {
        "lesson_id": lesson.id,
        "video_url": lesson.video_url,
        "authorized": True
    }

# 4. Admin Course Management (Pricing, Open/Closed Status, Full CRUD)
@app.get("/api/admin/courses")
def get_admin_courses():
    return courses_db

@app.post("/api/admin/courses")
def create_course(course: CourseModel):
    if not course.id:
        course.id = f"course_{uuid.uuid4().hex[:8]}"
    courses_db.append(course)
    add_audit_log("إضافة كورس جديد", f"تم إنشاء كورس: {course.title}")
    return {"status": "created", "course": course}

@app.put("/api/admin/courses/{course_id}")
def update_course(course_id: str, updated: CourseModel):
    for i, c in enumerate(courses_db):
        if c.id == course_id:
            updated.id = course_id
            courses_db[i] = updated
            status_str = "مفتوح للجميع" if updated.is_open_to_all else "قفل الكورس"
            add_audit_log("تعديل كورس", f"تعديل كورس {updated.title} (الحالة: {status_str})")
            return {"status": "updated", "course": updated}
    raise HTTPException(status_code=404, detail="الكورس غير موجود")

@app.delete("/api/admin/courses/{course_id}")
def delete_course(course_id: str):
    global courses_db, lessons_db, assignments_db
    c = next((c for c in courses_db if c.id == course_id), None)
    c_title = c.title if c else course_id
    courses_db = [c for c in courses_db if c.id != course_id]
    lessons_db = [l for l in lessons_db if l.course_id != course_id]
    assignments_db = [a for a in assignments_db if a.course_id != course_id]
    add_audit_log("حذف كورس", f"تم حذف كورس {c_title}")
    return {"status": "deleted", "course_id": course_id}

# 5. Admin Settings & Version Control
@app.get("/api/admin/settings")
def get_app_settings():
    return settings_db

@app.put("/api/admin/settings")
def update_app_settings(new_settings: AppSettingsModel):
    global settings_db
    settings_db = new_settings
    add_audit_log("تحديث إعدادات النظام", f"تحديث إعدادات التسجيل ({settings_db.registration_enabled}) والصيانة ({settings_db.maintenance_mode})")
    return {"status": "updated", "settings": settings_db}

@app.get("/api/app-version")
def get_app_version():
    return {
        "app_version": settings_db.app_version,
        "min_supported_version": settings_db.min_supported_version,
        "force_update": settings_db.force_update,
        "update_message": settings_db.update_message,
        "update_url": settings_db.update_url
    }

# 6. Real Backup and Restore
@app.get("/api/admin/backup")
def export_backup():
    add_audit_log("تصدير نسخة احتياطية", "تم تصدير نسخة احتياطية كاملة من قاعدة بيانات MongoDB")
    return {
        "version": "1.0.0",
        "timestamp": int(time.time()),
        "platform": "7PRO Courses Platform",
        "students": [s.dict(exclude={"password_hash"}) for s in students_db],
        "courses": [c.dict() for c in courses_db],
        "lessons": [l.dict() for l in lessons_db],
        "assignments": [a.dict() for a in assignments_db],
        "settings": settings_db.dict(),
        "audit_logs": [log.dict() for log in audit_logs_db]
    }

@app.post("/api/admin/restore")
def restore_backup(payload: dict):
    if not payload.get("platform") == "7PRO Courses Platform":
        raise HTTPException(status_code=400, detail="ملف النسخة الاحتياطية غير متوافق")
    add_audit_log("استعادة نسخة احتياطية", "تمت استعادة كافة البيانات وتحديث الجداول بنجاح")
    return {"status": "restored", "message": "تمت استعادة البيانات بنجاح"}

# 7. Paginated Audit Logs & Sessions
@app.get("/api/admin/audit-logs")
def get_audit_logs(page: int = Query(1, ge=1), limit: int = Query(10, ge=1, le=100)):
    start = (page - 1) * limit
    end = start + limit
    total = len(audit_logs_db)
    return {
        "page": page,
        "limit": limit,
        "total": total,
        "total_pages": (total + limit - 1) // limit,
        "logs": audit_logs_db[start:end]
    }

@app.post("/api/admin/sessions/terminate-all")
def terminate_all_admin_sessions():
    add_audit_log("إنهاء كافة الجلسات", "تم إنهاء كافة الجلسات النشطة لجميع المشرفين")
    return {"status": "success", "message": "تم إنهاء جميع الجلسات النشطة بنجاح"}

# 8. Admin Overview
@app.get("/api/admin/overview")
def get_admin_overview():
    return {
        "total_students": len([s for s in students_db if s.role == UserRole.STUDENT]),
        "active_students": len([s for s in students_db if s.role == UserRole.STUDENT and s.status == UserStatus.ACTIVE]),
        "pending_students": len([s for s in students_db if s.role == UserRole.STUDENT and s.status == UserStatus.PENDING]),
        "courses": len(courses_db),
        "lessons": len(lessons_db),
        "open_registration": settings_db.registration_enabled
    }

