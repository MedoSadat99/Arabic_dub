from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from enum import Enum
import time

class UserRole(str, Enum):
    STUDENT = "STUDENT"
    ADMIN = "ADMIN"

class UserStatus(str, Enum):
    ACTIVE = "ACTIVE"
    PENDING = "PENDING"
    DISABLED = "DISABLED"

class StudentModel(BaseModel):
    id: Optional[str] = None
    name: str
    email: EmailStr
    password_hash: str
    status: UserStatus = UserStatus.ACTIVE
    role: UserRole = UserRole.STUDENT
    created_at: int = Field(default_factory=lambda: int(time.time()))

class CourseModel(BaseModel):
    id: Optional[str] = None
    title: str
    description: str
    image_url: str
    is_open_to_all: bool = False  # False = Requires individual student activation, True = Open to all
    is_published: bool = True
    is_hidden: bool = False
    display_order: int = 0
    created_at: int = Field(default_factory=lambda: int(time.time()))

class LessonModel(BaseModel):
    id: Optional[str] = None
    course_id: str
    title: str
    duration: str
    video_url: str
    display_order: int = 0
    status: str = "published"

class CourseAssignmentModel(BaseModel):
    id: Optional[str] = None
    student_id: str
    course_id: str
    assigned_at: int = Field(default_factory=lambda: int(time.time()))

class LessonProgressModel(BaseModel):
    student_id: str
    course_id: str
    lesson_id: str
    is_completed: bool = False
    progress_seconds: int = 0
    last_watched_at: int = Field(default_factory=lambda: int(time.time()))

class AppSettingsModel(BaseModel):
    registration_enabled: bool = True
    maintenance_mode: bool = False
    maintenance_message: str = "المنصة قيد الصيانة الدورية لتحسين التجربة، سنعود قريباً!"
    app_version: str = "1.0.0"
    min_supported_version: str = "1.0.0"
    force_update: bool = False
    update_message: str = "يوجد تحديث جديد متاح لمنصة 7PRO بميزات وتحسينات جديدة."
    update_url: str = "https://7pro.com/download"

class AppearanceSettingsModel(BaseModel):
    logo_url: str = "ic_7pro_logo"
    hero_headline: str = "دورات 7PRO لتعلّم الإنجليزية"
    welcome_text: str = "طوّر لغتك الإنجليزية مع نخبة من الدورات الاحترافية"

class PasswordResetModel(BaseModel):
    code: str
    email: str
    expires_at: int
    is_used: bool = False

class AuditLogModel(BaseModel):
    id: str
    timestamp: int = Field(default_factory=lambda: int(time.time()))
    action: str
    details: str
    admin_email: str
    ip_address: str = "127.0.0.1"

